import DefaultLayout from '../layouts/DefaultLayout'
import navLinks from '../assets/data/headerLinks.json'
import Container from '../components/ui/Container'
import Image from 'next/image'
import Link from 'next/link'

import profile3d from '../../public/images/user-profile-3d.png'
import link3d from '../../public/images/link-3d.png'
import speaker3d from '../../public/images/speaker-3d.png'
import { Fragment, useState } from 'react'

const Referral = () => {
  const [isUserSignedIn, setIsUserSignedIn] = useState(true)
  const [percentage, setPercentage] = useState(0)
  const [generatedLink, setGeneratedLink] = useState('')

  const gridClasses = isUserSignedIn ? 'lg:grid-cols-2' : 'lg:grid-cols-3'

  const setPercentageHandler = value => () => setPercentage(value)
  const setGeneratedLinkHandler = () => {
    // ... some work ...
    setGeneratedLink('somelinkandtext')
  }
  const copyHandler = () => {
    navigator.clipboard.writeText(generatedLink).then()
  }
  const customCopyHandler = (text = '') => {
    navigator.clipboard.writeText(text).then()
  }

  return (
    <div
      dir='rtl'
      className='text-gray-700 bg-[url("/images/about-us-bg.png")] bg-repeat-y bg-[length:100%_auto] min-h-screen'>
      <Container>
        <h1 className='block w-fit mx-auto text-3xl font-bold text-white bg-primary py-3 px-8 rounded-full mb-8'>
          دعوت از دوستان
        </h1>
        <section className='mb-12'>
          <h3 className='text-2xl font-bold mb-1'>
            بدون معامله کردن هم پول در بیارید!
          </h3>
          <p className='text-xl text-justify mb-8'>
            سیستم دعوت از دوستان صراف 24 یک سیستم درآمدزایی برای کاربران است.
            فقط کافیست مارا به دوستانتان معرفی کنید تا ما 30 درصد از کارمزد
            معاملات آنها را به حساب شما واریز کنیم.
          </p>
          <div className='bg-gradient-to-br from-black/90 to-black/60 rounded-3xl py-4 px-6 text-gray-200'>
            <div className='flex flex-row items-center justify-between mb-4'>
              <h4 className='font-bold text-2xl'>
                چگونه دوستانمان را دعوت کنیم ؟
              </h4>
              {!isUserSignedIn && (
                <Link
                  href='/signin'
                  className='button bg-white hover:bg-gray-200 active:bg-gray-300 text-primary font-bold'>
                  ورود / ثبت نام
                </Link>
              )}
            </div>
            <div
              role='list'
              className={`grid grid-cols-1 ${gridClasses} gap-4`}>
              {!isUserSignedIn && (
                <div
                  role='listitem'
                  className='flex flex-row items-center gap-4'>
                  <div className='w-14 h-14 shrink-0'>
                    <Image
                      className='w-full h-full'
                      src={profile3d}
                      alt={'profile-pic-3d'}
                    />
                  </div>
                  <div>
                    <h5 className='text-lg font-bold'>ورود به حساب کاربری</h5>
                    <p>
                      وارد حساب کاربری خود شده و روی گزینه “معرفی دوستان” کلیک
                      کنید.
                    </p>
                  </div>
                </div>
              )}
              {/* ---- */}
              <div role='listitem' className='flex flex-row items-center gap-4'>
                <div className='w-14 h-14 shrink-0'>
                  <Image
                    className='w-full h-full'
                    src={link3d}
                    alt={'profile-pic-3d'}
                  />
                </div>
                <div>
                  <h5 className='text-lg font-bold'>دریافت لینک</h5>
                  <p>لینک دعوت یا کد QR را با تنظیمات دلخواه دریافت کنید. </p>
                </div>
              </div>
              {/* ---- */}
              <div role='listitem' className='flex flex-row items-center gap-4'>
                <div className='w-14 h-14 shrink-0'>
                  <Image
                    className='w-full h-full'
                    src={speaker3d}
                    alt={'profile-pic-3d'}
                  />
                </div>
                <div>
                  <h5 className='text-lg font-bold'>شبکه های اجتماعی</h5>
                  <p>
                    دوستان خود را از طریق شبکه های اجتماعی به صراف 24 دعوت کنید.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        {isUserSignedIn && (
          <Fragment>
            <section className='mb-12'>
              <h3 className='text-center text-3xl font-bold mb-1'>
                دریافت لینک دعوت
              </h3>
              <p className='text-center text-lg mb-6'>
                30 درصد کارمزد معاملات دوستانتان برای شما خواهد بود و شما
                میتوانید هر میزان از آن را به دلخواه به خودشان برگردانید.
              </p>
              <div className='grid grid-cols-1 lg:grid-cols-2 bg-gradient-to-br from-black/90 to-black/60 text-white rounded-3xl py-8 px-6 gap-10'>
                <div>
                  <div className='flex flex-row items-center border-solid border-b-2 border-b-white py-1.5 mb-2'>
                    <span className='grow'>{generatedLink}</span>
                    <button onClick={copyHandler}>
                      <svg
                        xmlns='http://www.w3.org/2000/svg'
                        fill='none'
                        viewBox='0 0 24 24'
                        strokeWidth={1.5}
                        stroke='currentColor'
                        className='w-6 h-6 shrink-0'>
                        <path
                          strokeLinecap='round'
                          strokeLinejoin='round'
                          d='M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 01-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 011.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 00-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 01-1.125-1.125v-9.25m12 6.625v-1.875a3.375 3.375 0 00-3.375-3.375h-1.5a1.125 1.125 0 01-1.125-1.125v-1.5a3.375 3.375 0 00-3.375-3.375H9.75'
                        />
                      </svg>
                    </button>
                  </div>
                  <button className='button mb-10' onClick={setGeneratedLinkHandler}>ایجاد لینک</button>
                  <p>تعداد دعوت از طرف شما: 0 نفر</p>
                </div>
                <div>
                  <p className='font-bold text-xl mb-2'>
                    میزان برگشت مبلغ به دوستتان را مشخص کنید:
                  </p>
                  <div className='flex flex-row flex-wrap font-sans gap-4 mb-4'>
                    <button
                      onClick={setPercentageHandler(0)}
                      className='button'>
                      0%
                    </button>
                    <button
                      onClick={setPercentageHandler(5)}
                      className='button'>
                      5%
                    </button>
                    <button
                      onClick={setPercentageHandler(10)}
                      className='button'>
                      10%
                    </button>
                    <button
                      onClick={setPercentageHandler(15)}
                      className='button'>
                      15%
                    </button>
                    <button
                      onClick={setPercentageHandler(20)}
                      className='button'>
                      20%
                    </button>
                    <button
                      onClick={setPercentageHandler(25)}
                      className='button'>
                      25%
                    </button>
                    <button
                      onClick={setPercentageHandler(30)}
                      className='button'>
                      30%
                    </button>
                  </div>
                  <div className='flex flex-row justify-between items-center'>
                    <p>دریافتی شما: {30 - percentage} درصد</p>
                    <p>دریافتی دوست: {percentage} درصد</p>
                  </div>
                </div>
              </div>
            </section>
            <section className='mb-12'>
              <h3 className='text-3xl font-bold text-center mb-8'>دریافتی شما</h3>
              <div className="w-full lg:w-3/4 mx-auto bg-gradient-to-br from-black/90 to-black/60 py-8 px-6 rounded-3xl text-gray-100 overflow-x-auto">
                <table className='min-w-full table-fixed'>
                  <thead>
                    <tr>
                      <th className='px-4 py-1'>نام ارز</th>
                      <th className='px-4 py-1'>دریافتی شما</th>
                    </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td className='py-1 px-4 font-sans border-solid border-b-white/50 border-b'>BTC</td>
                    <td className='py-1 px-4 font-sans border-solid border-b-white/50 border-b'>0.000000152 BTC</td>
                  </tr>
                  <tr>
                    <td className='py-1 px-4 font-sans'>BTC</td>
                    <td className='py-1 px-4 font-sans'>0.000000152 BTC</td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </section>
            <section className='mb-12'>
              <h3 className='text-center font-bold text-3xl mb-6'>لینک های ساخته شده</h3>
              <div className="w-full lg:w-3/4 mx-auto bg-gradient-to-br from-black/90 to-black/60 py-8 px-6 rounded-3xl text-gray-100 overflow-x-auto">
                <table className='min-w-full table-fixed'>
                  <thead>
                  <tr className='text-xl'>
                    <th className='px-4 py-1'>لینک</th>
                    <th className='px-4 py-1'>شما / دوست</th>
                    <th className='px-4 py-1'>تعداد</th>
                    <th className='px-4 py-1'></th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td className='py-1 px-4 font-sans border-solid border-b-white/50 border-b'>fadFFfFwSsFagAveSdf</td>
                    <td className='py-1 px-4 font-sans border-solid border-b-white/50 border-b'>30% / 0%</td>
                    <td className='py-1 px-4 font-sans border-solid border-b-white/50 border-b'>0</td>
                    <td className='py-1 px-4 border-solid border-b-white/50 border-b'>
                      <button onClick={() => customCopyHandler('fadFFfFwSsFagAveSdf')} className='button'>کپی لینک</button>
                    </td>
                  </tr>
                  <tr>
                    <td className='py-1 px-4 font-sans'>fadFFfFwSsFagAveSdf</td>
                    <td className='py-1 px-4 font-sans'>30% / 0%</td>
                    <td className='py-1 px-4 font-sans'>0</td>
                    <td className='py-1 px-4'>
                      <button onClick={() => customCopyHandler('fadFFfFwSsFagAveSdf')} className='button'>کپی لینک</button>
                    </td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </section>
            <section className='mb-12'>
              <h3 className='text-3xl font-bold text-center mb-8'>تاریخچه دعوت</h3>
              <div className="w-full lg:w-3/4 mx-auto bg-gradient-to-br from-black/90 to-black/60 py-8 px-6 rounded-3xl text-gray-100 overflow-x-auto">
                <table className='min-w-full table-fixed'>
                  <thead>
                  <tr>
                    <th className='px-4 py-1'>حساب دوست</th>
                    <th className='px-4 py-1'>درصد دریافتی شما</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td className='py-1 px-4 font-sans border-solid border-b-white/50 border-b'>Saraf-24</td>
                    <td className='py-1 px-4 font-sans border-solid border-b-white/50 border-b'>30%</td>
                  </tr>
                  <tr>
                    <td className='py-1 px-4 font-sans'>Saraf-24</td>
                    <td className='py-1 px-4 font-sans'>30%</td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </section>
          </Fragment>
        )}
      </Container>
    </div>
  )
}

Referral.getLayout = (page, props) => (
  <DefaultLayout
    navbar
    footer
    title='Referral'
    navLinks={navLinks.links}
    theme='light'>
    {page}
  </DefaultLayout>
)

export default Referral
