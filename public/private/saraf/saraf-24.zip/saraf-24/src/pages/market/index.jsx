import { Fragment, useCallback, useState } from 'react'
import createStaticPropsWithNavData from '../../api/helpers/navdata'
import DefaultLayout from '../../layouts/DefaultLayout'
import Container from '../../components/ui/Container'
import UnitButton from '../../components/pages/market/UnitButton'
import MarketTable from '../../components/pages/market/MarketTable'
import MarketTableRow from '../../components/pages/market/MarketTableRow'
import marketCoins from '../../assets/data/marketCoins.json'
import Category from '../../components/pages/market/Category'

export default function Market(props) {
  const [selectedUnit, setSelectedUnit] = useState('toman')

  const activeUnitHandler = unit => (selectedUnit === unit ? 'border-b-primary' : 'border-b-transparent')
  const setSelectedHandler = useCallback(unit => {
    setSelectedUnit(unit)
  }, [])

  const coinsList = marketCoins.map(marketCoin => (
    <MarketTableRow
      key={marketCoin.id}
      icon={marketCoin.icon}
      name={marketCoin.name}
      symbol={marketCoin.symbol}
      price={marketCoin.price}
      changes={marketCoin.changes}
      changesChart={marketCoin.changesChart}
      unit={selectedUnit}
    />
  ))

  return (
    <Fragment>
      <Container dir='rtl'>
        <h2 className='text-2xl mb-4'>بازار ارز های دیجیتال</h2>
        <div className='flex flex-row items-center w-full max-w-sm border-solid border-b border-b-gray-400 cursor-text'>
          <input className='py-2 grow' type='text' placeholder='جستوجو نام ارز دیجیتال' />
          <svg
            xmlns='http://www.w3.org/2000/svg'
            fill='none'
            viewBox='0 0 24 24'
            strokeWidth={1.5}
            stroke='currentColor'
            className='w-6 h-6 shrink-0'>
            <path
              strokeLinecap='round'
              strokeLinejoin='round'
              d='M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z'
            />
          </svg>
        </div>
      </Container>
      <Container dir='rtl'>
        <div className='flex flex-row items-stretch gap-1 mb-2'>
          <UnitButton name='تومان' unit='toman' onActivate={activeUnitHandler} onSelect={setSelectedHandler} />
          <UnitButton name='تتر' unit='teter' onActivate={activeUnitHandler} onSelect={setSelectedHandler} />
          <UnitButton
            name='دسته بندی ارز ها'
            unit='category'
            onActivate={activeUnitHandler}
            onSelect={setSelectedHandler}
          />
        </div>
        {selectedUnit === 'category' && (
          <div className='mb-4 flex flex-row flex-wrap'>
            <Category>استیبل کوین</Category>
            <Category>میم کوین</Category>
            <Category>ان اف تی</Category>
            <Category>دیفای</Category>
            <Category>وب 3</Category>
            <Category>متاورس</Category>
            <Category>توکن هواداری</Category>
          </div>
        )}
        <MarketTable>{coinsList}</MarketTable>
      </Container>
    </Fragment>
  )
}

Market.getLayout = (page, props) => (
  <DefaultLayout navbar footer navLinks={props.navLinks} title='فروشگاه'>
    {page}
  </DefaultLayout>
)
export const getStaticProps = createStaticPropsWithNavData()
