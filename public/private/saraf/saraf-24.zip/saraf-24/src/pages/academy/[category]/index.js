import React, { useEffect } from 'react'
import DefaultLayout from '../../../layouts/DefaultLayout'
import navLinks from '../../../assets/data/academyLinks.json'
import titles from '../../../assets/data/academyCategory.json'
import Container from '../../../components/ui/Container'
import { useRouter } from 'next/router'

const getTitle = async ctx => titles.find(value => value.id === ctx.params.category)?.title

export default function AcademyCategory({ pageTitle }) {
  const router = useRouter()

  useEffect(() => {
    router.replace(router.asPath).then()
  }, [router.query?.category])

  return (
    <Container className='text-gray-700'>
      <form action='#' className='flex flex-row items-center max-w-md ml-auto border-solid border-b-2 border-black/80' dir='rtl'>
        <input className='grow py-2' type="text" placeholder='جست و جو کنید' name='search'/>
        <button className='shrink-0'>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
          </svg>
        </button>
      </form>
      <h3 className='w-fit mx-auto text-4xl font-bold border-solid border-b-[0.15rem] border-b-primary mb-6 pb-2'>
        {pageTitle}
      </h3>
      <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-8 mb-6' dir='rtl'>
        <a href='#' className='flex flex-col justify-end z-0 relative aspect-square bg-gray-300 shadow-md rounded-3xl overflow-hidden p-4 text-white'>
          <img
            src='/images/what-is-nft.png'
            alt='nft'
            className='absolute top-0 left-0 w-full h-full object-cover z-[-1]'
          />
          <h3 className='text-3xl drop-shadow-md'>بلاکچین چیست؟</h3>
          <p className='text-3xl drop-shadow-md'>توضیحات ساده همراه با مثال‌های کاربردی</p>
        </a>
        <a href='#' className='flex flex-col justify-end z-0 relative aspect-square bg-gray-300 shadow-md rounded-3xl overflow-hidden p-4 text-white'>
          <img
            src='/images/what-is-nft.png'
            alt='nft'
            className='absolute top-0 left-0 w-full h-full object-cover z-[-1]'
          />
          <h3 className='text-3xl drop-shadow-md'>بلاکچین چیست؟</h3>
          <p className='text-3xl drop-shadow-md'>توضیحات ساده همراه با مثال‌های کاربردی</p>
        </a>
        <a href='#' className='flex flex-col justify-end z-0 relative aspect-square bg-gray-300 shadow-md rounded-3xl overflow-hidden p-4 text-white'>
          <img
            src='/images/what-is-nft.png'
            alt='nft'
            className='absolute top-0 left-0 w-full h-full object-cover z-[-1]'
          />
          <h3 className='text-3xl drop-shadow-md'>بلاکچین چیست؟</h3>
          <p className='text-3xl drop-shadow-md'>توضیحات ساده همراه با مثال‌های کاربردی</p>
        </a>
        <a href='#' className='flex flex-col justify-end z-0 relative aspect-square bg-gray-300 shadow-md rounded-3xl overflow-hidden p-4 text-white'>
          <img
            src='/images/what-is-nft.png'
            alt='nft'
            className='absolute top-0 left-0 w-full h-full object-cover z-[-1]'
          />
          <h3 className='text-3xl drop-shadow-md'>بلاکچین چیست؟</h3>
          <p className='text-3xl drop-shadow-md'>توضیحات ساده همراه با مثال‌های کاربردی</p>
        </a>
        <a href='#' className='flex flex-col justify-end z-0 relative aspect-square bg-gray-300 shadow-md rounded-3xl overflow-hidden p-4 text-white'>
          <img
            src='/images/what-is-nft.png'
            alt='nft'
            className='absolute top-0 left-0 w-full h-full object-cover z-[-1]'
          />
          <h3 className='text-3xl drop-shadow-md'>بلاکچین چیست؟</h3>
          <p className='text-3xl drop-shadow-md'>توضیحات ساده همراه با مثال‌های کاربردی</p>
        </a>
        <a href='#' className='flex flex-col justify-end z-0 relative aspect-square bg-gray-300 shadow-md rounded-3xl overflow-hidden p-4 text-white'>
          <img
            src='/images/what-is-nft.png'
            alt='nft'
            className='absolute top-0 left-0 w-full h-full object-cover z-[-1]'
          />
          <h3 className='text-3xl drop-shadow-md'>بلاکچین چیست؟</h3>
          <p className='text-3xl drop-shadow-md'>توضیحات ساده همراه با مثال‌های کاربردی</p>
        </a>
        <a href='#' className='flex flex-col justify-end z-0 relative aspect-square bg-gray-300 shadow-md rounded-3xl overflow-hidden p-4 text-white'>
          <img
            src='/images/what-is-nft.png'
            alt='nft'
            className='absolute top-0 left-0 w-full h-full object-cover z-[-1]'
          />
          <h3 className='text-3xl drop-shadow-md'>بلاکچین چیست؟</h3>
          <p className='text-3xl drop-shadow-md'>توضیحات ساده همراه با مثال‌های کاربردی</p>
        </a>
        <a href='#' className='flex flex-col justify-end z-0 relative aspect-square bg-gray-300 shadow-md rounded-3xl overflow-hidden p-4 text-white'>
          <img
            src='/images/what-is-nft.png'
            alt='nft'
            className='absolute top-0 left-0 w-full h-full object-cover z-[-1]'
          />
          <h3 className='text-3xl drop-shadow-md'>بلاکچین چیست؟</h3>
          <p className='text-3xl drop-shadow-md'>توضیحات ساده همراه با مثال‌های کاربردی</p>
        </a>
        <a href='#' className='flex flex-col justify-end z-0 relative aspect-square bg-gray-300 shadow-md rounded-3xl overflow-hidden p-4 text-white'>
          <img
            src='/images/what-is-nft.png'
            alt='nft'
            className='absolute top-0 left-0 w-full h-full object-cover z-[-1]'
          />
          <h3 className='text-3xl drop-shadow-md'>بلاکچین چیست؟</h3>
          <p className='text-3xl drop-shadow-md'>توضیحات ساده همراه با مثال‌های کاربردی</p>
        </a>
      </div>
      <div className='flex flex-col md:flex-row-reverse items-center md:justify-between gap-1'>
        <div className='w-24'></div>
        <div>
          <button className='button text-2xl'>صفحه بعدی</button>
        </div>
        <div className='flex flex-row items-stretch gap-1' dir='rtl'>
          <button className='text-white bg-black/90 p-0.5 rounded-md'>
            <svg
              xmlns='http://www.w3.org/2000/svg'
              fill='none'
              viewBox='0 0 24 24'
              strokeWidth='1.5'
              stroke='currentColor'
              className='w-6 h-6'>
              <path strokeLinecap='round' strokeLinejoin='round' d='M8.25 4.5l7.5 7.5-7.5 7.5' />
            </svg>
          </button>
          <span className='leading-7'>1</span>
          <button className='text-white bg-black/90 p-0.5 rounded-md'>
            <svg
              xmlns='http://www.w3.org/2000/svg'
              fill='none'
              viewBox='0 0 24 24'
              strokeWidth={1.5}
              stroke='currentColor'
              className='w-6 h-6'>
              <path strokeLinecap='round' strokeLinejoin='round' d='M15.75 19.5L8.25 12l7.5-7.5' />
            </svg>
          </button>
          <span className="hidden md:block leading-7">از 10</span>
        </div>
      </div>
    </Container>
  )
}

AcademyCategory.getLayout = page => (
  <DefaultLayout footer navbar title={'دسته بندی'} theme='light' navLinks={navLinks.links}>
    {page}
  </DefaultLayout>
)

export async function getServerSideProps(ctx) {
  const title = await getTitle(ctx)

  return {
    props: {
      pageTitle: title,
    },
    ...(!title && { notFound: true }),
  }
}