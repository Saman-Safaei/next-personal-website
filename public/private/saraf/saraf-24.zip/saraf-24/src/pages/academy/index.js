import React from 'react'
import DefaultLayout from '../../layouts/DefaultLayout'
import navData from '../../assets/data/academyLinks.json'
import slides from '../../assets/data/academySlides.json'
import Container from '../../components/ui/Container'
import HeaderSlider from '../../components/pages/academy/HeaderSlider'
import NewsCard from '../../components/pages/academy/NewsCard'
import AnalysisCard from "../../components/pages/academy/AnalysisCard";
import {Splide, SplideSlide, SplideTrack} from '@splidejs/react-splide';
import NewPostsSlider from "../../components/pages/academy/NewPostsSlider";

export default function Academy(props) {
  return (
    <Container className='text-gray-800'>
      <HeaderSlider slides={slides} />
      <NewPostsSlider />
      <section className='py-4'>
        <h3 className='w-fit mx-auto text-3xl font-bold pb-1 lg:text-4xl border-solid border-b-2 border-b-primary mb-5'>
          مفاهیم پایه ارز دیجیتال
        </h3>
        <div
          className='grid grid-cols-1 lg:grid-cols-2 lg:grid-rows-2 aspect-[9/16] lg:aspect-[16/9] gap-6 text-white'
          dir='rtl'>
          <a href='#' className='relative rounded-3xl overflow-hidden'>
            <img src='/images/bitcoin-creation.png' alt='non-sense' className='h-full w-full object-cover' />
            <div className='flex justify-center lg:justify-start items-center absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-black/60 to-black/10 z-10 p-1'>
              <h4 className='lg:max-w-[50%] p-4 text-2xl md:text-3xl text-center'>پیدایش بیتکوین از ابتدا تا حال</h4>
            </div>
          </a>
          <a
            href='#'
            className='relative lg:row-start-1 lg:row-end-3 lg:col-start-1 lg:col-end-2 rounded-3xl overflow-hidden'>
            <img src='/images/airdrop.png' alt='non-sense' className='h-full w-full object-cover' />
            <div className='flex flex-col justify-center lg:justify-end absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10 p-2'>
              <h4 className='p-4 text-2xl md:text-3xl lg:text-4xl text-center lg:text-start'>
                لذت دریافت ارزدیجیتال رایگان با ایردراپ!
              </h4>
            </div>
          </a>
          <a href='#' className='relative rounded-3xl overflow-hidden'>
            <img src='/images/what-is-nft.png' alt='non-sense' className='h-full w-full object-cover' />
            <div className='flex justify-center lg:justify-end items-center absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-black/60 to-black/10 z-10 p-1'>
              <h4 className='lg:max-w-[50%] p-4 text-2xl md:text-3xl text-center'>NFT یا توکن های غیر قابل تعویض</h4>
            </div>
          </a>
        </div>
      </section>
      <section className='py-4'>
        <h3 className='w-fit mx-auto text-3xl font-bold pb-1 lg:text-4xl border-solid border-b-2 border-b-primary mb-5'>
          اخبار
        </h3>
        <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4'>
          <NewsCard
            title='بیت‌ کوین؛ یک الگوی جدید سرمایه‌گذاری'
            image='/images/tshirtman.png'
            date='25 دی 1401'
            link='#'
          />
          <NewsCard
            title='بیت‌ کوین؛ یک الگوی جدید و نوین سرمایه‌گذاری در بازار دیجیتال ارز'
            image='/images/tshirtman.png'
            date='25 دی 1401'
            link='#'
          />
          <NewsCard
            title='بیت‌ کوین؛ یک الگوی جدید سرمایه‌گذاری'
            image='/images/tshirtman.png'
            date='25 دی 1401'
            link='#'
          />
          <NewsCard
            title='بیت‌ کوین؛ یک الگوی جدید سرمایه‌گذاری'
            image='/images/tshirtman.png'
            date='25 دی 1401'
            link='#'
          />
        </div>
        <div className='w-full flex flex-col md:flex-row items-stretch md:items-center gap-2 py-6' dir='rtl'>
          <p className='grow text-2xl text-center md:text-start'>
            اخبار دنیای ارزدیجیتال و صراف 24 را از طریق ایمیل دریافت کنید!
          </p>
          <div className='shrink-0 w-full md:w-80 flex flex-row border-solid border-b-2 border-b-gray-600 py-1'>
            <input type='text' placeholder='ایمیل خود را وارد کنید' />
            <button className='button text-sm whitespace-nowrap'>ارسال خبرنامه</button>
          </div>
        </div>
      </section>
      <section className='py-4'>
        <h3 className='w-fit mx-auto text-3xl font-bold pb-1 lg:text-4xl border-solid border-b-2 border-b-primary mb-5'>
          تحلیل و سرمایه گذاری
        </h3>
        <div className='grid gap-4 grid-cols-1 md:grid-cols-2'>
          <AnalysisCard title='تحلیل آنچین هفته دوم دی ماه' image='/images/bitcoin-creation.png' />
          <AnalysisCard title='تحلیل آنچین هفته دوم دی ماه' image='/images/bitcoin-creation.png' />
          <AnalysisCard title='تحلیل آنچین هفته دوم دی ماه' image='/images/bitcoin-creation.png' />
          <AnalysisCard title='تحلیل آنچین هفته دوم دی ماه' image='/images/bitcoin-creation.png' />
        </div>
      </section>
    </Container>
  )
}

Academy.getLayout = children => (
  <DefaultLayout navLinks={navData.links} title='آکادمی' navbar theme='light' footer>
    {children}
  </DefaultLayout>
)
