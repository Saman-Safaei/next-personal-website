import DefaultLayout from '../../layouts/DefaultLayout'
import Container from '../../components/ui/Container'
import React, { useMemo, useState } from 'react'
import links from '../../assets/data/headerLinks.json'
import useTrade from '../../hooks/useTrade'

import StepOne from '../../components/pages/trade/StepOne'
import Receive1 from '../../components/pages/trade/Receive/Step1'
import Receive2 from '../../components/pages/trade/Receive/Step2'
import Sell1 from '../../components/pages/trade/Sell/Step1'
import Sell2 from '../../components/pages/trade/Sell/Step2'
import { useRouter } from 'next/router'
import Receive3 from '../../components/pages/trade/Receive/Step3'
import NotEnough from '../../components/pages/trade/Receive/NotEnough'

export default function Trade({ coins, initialMethod, transitionCode }) {
  const { state, actions } = useTrade(initialMethod, transitionCode)

  const steps = useMemo(
    () => [
      <StepOne
        coins={coins}
        actions={actions}
        state={state}
        nextHandler={nextStepHandler}
      />,
      [
        <Receive1 state={state} actions={actions} nextStep={nextStepHandler} />,
        <Receive2
          state={state}
          actions={actions}
          nextStep={nextStepHandler}
          resetStep={resetStepHandler}
          noEnoughCredit={<NotEnough state={state} />}
        />,
        <Receive3 state={state} actions={actions} />,
      ],
      [
        <Sell1
          resetStep={resetStepHandler}
          state={state}
          nextStep={nextStepHandler}
        />,
        <Sell2 state={state} />,
      ],
    ],
    [state]
  )

  function nextStepHandler() {
    if (
      (state.method === 0 && state.step > steps[1].length - 1) ||
      (state.method === 1 && state.step > steps[2].length - 1)
    )
      return

    actions.setStep(state.step + 1)
  }

  function resetStepHandler() {
    actions.setStep(0)
  }

  const activePage =
    state.step === 0
      ? steps[0]
      : state.method === 0
      ? steps[1][state.step - 1]
      : state.method === 1
      ? steps[2][state.step - 1]
      : null

  return (
    <Container>
      <div className='max-w-md mx-auto bg-gradient-to-br from-white/30 backdrop-blur-sm to-transparent rounded-3xl p-8'>
        {activePage}
      </div>
    </Container>
  )
}

Trade.getLayout = (page, props) => {
  return (
    <DefaultLayout navbar footer title='معامله' navLinks={links.links}>
      <img
        src='/images/tradebg.png'
        alt='tradebg'
        className='fixed h-full w-full object-center -z-10'
      />
      {page}
    </DefaultLayout>
  )
}

export async function getServerSideProps(ctx) {
  const coinsResponse = await fetch('http://localhost:3000/api/currencies')
  const coinsData = await coinsResponse.json()
  
  const initialMethod = isNaN(+ctx.query.m) ? null : +ctx.query.m;
  const transitionCode = ctx.query.t ?? null;

  return {
    props: {
      coins: coinsData.data,
      initialMethod,
      transitionCode
    },
  }
}
