import Link from 'next/link'
import { Fragment } from 'react'
import DefaultLayout from '../layouts/DefaultLayout'
import createStaticPropsWithNavData from '../api/helpers/navdata'

export default function Home() {
  return (
    <div className='flex flex-col items-center gap-4'>
      <Link href='/user/saman/wallet'>کیف پول</Link>
      <Link href='/user/saman/wallet/deposite'>واریز آنلاین</Link>
      <Link href='/user/saman/wallet/withdrawCoin'>برداشت آنلاین کوین</Link>
      <Link href='/user/saman/wallet/withdraw'>برداشت آنلاین</Link>
      <Link href='/auth'>احراز هویت</Link>
      <Link href='/signup'>ثبت نام</Link>
      <Link href='/signin'>ورود</Link>
      <Link href='/trade/Trade'>معامله</Link>
      <Link href='/faq'>سوالات متداول</Link>
      <Link href='/contact-us'>تماس با ما</Link>
      <Link href='/about-us'>درباره ما</Link>
      <Link href='/market'>مارکت دیجیتال</Link>
      <Link href='/application'>اپلیکیشن</Link>
      <Link href='/academy'>آکادمی</Link>
    </div>
  )
}

Home.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='صفحه اصلی' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
