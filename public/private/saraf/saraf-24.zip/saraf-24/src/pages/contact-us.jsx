import Container from '../components/ui/Container'
import DefaultLayout from '../layouts/DefaultLayout'
import styles from '../styles/ContactUS.module.css'
import createStaticPropsWithNavData from "../api/helpers/navdata";

export default function ContactUS() {
  return (
    <Container className={styles['container-bg']}>
      <div
        className={`${styles['black-box']} bg-black/50 rounded-3xl pt-14 px-8 pb-28 max-w-4xl mx-auto`}>
        <div className='flex flex-row items-center gap-2'>
          <img src='/images/logo.png' className='w-20' />
          <span className='fenton text-xl font-bold'>Saraf 24</span>
        </div>
        <div className='flex flex-col lg:flex-row items-center lg:items-end gap-4'>
          <div className='w-full md:w-1/2 lg:w-1/3 shrink-0'>
            <img
              className='w-full p-6'
              src='/images/contactus.png'
              alt='contactus'
            />
          </div>
          <div className='grow' dir='rtl'>
            <h3 className='text-3xl font-bold mb-8'>با ما در تماس باشید:</h3>
            <p className='text-2xl font-bold mb-5'>
              آدرس: جنت آباد شمالی، بین بهارستان دوازدهم و چهارراه گلستان پلاک
              313 طبقه 3
            </p>
            <p className='text-2xl font-bold mb-5'>تلفن: 02191098564</p>
            <p className='text-xl font-bold'>ایمیل: <span className='fenton font-normal'>info@saraf24.com</span></p>
          </div>
        </div>
      </div>
    </Container>
  )
}

ContactUS.getLayout = (page, props) => (
  <DefaultLayout title='تماس با ما' navbar footer theme='light' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()