import Link from 'next/link'
import { useRouter } from 'next/router'
import Container from '../../../../components/ui/Container'
import DefaultLayout from '../../../../layouts/DefaultLayout'
import InputSelect from '../../../../components/ui/InputSelect'
import SelectBox from '../../../../components/ui/SelectBox'
import { Fragment, useRef, useState } from 'react'
import createStaticPropsWithNavData from '../../../../api/helpers/navdata'

export default function Deposite() {
  const router = useRouter()
  const coins = [
    { title: 'تومان', value: 'irt' },
    { title: 'بیت کوین', value: 'btc' },
    { title: 'تتر', value: 'usdt' },
  ]

  const [selectedCoin, setSelectedCoin] = useState('')

  const coinChangeHandler = coin => {
    setSelectedCoin(coin)
  }

  return (
    <Container>
      <PageHeader router={router} />
      <div className='flex flex-col lg:flex-row items-stretch lg:items-center w-full'>
        <div className='w-full md:w-1/2 lg:w-5/12 shrink-0'>
          <img src='/images/depositelogo.png' alt='deposite-logo' className='w-full' />
        </div>
        <div className='grow flex flex-col items-stretch gap-8' dir='rtl'>
          <div>
            <h4 className='text-xl font-bold'>انتخاب رمز ارز</h4>
            <InputSelect
              className='max-w-sm border-solid border-b-white border-b'
              items={coins}
              defaultValue={router?.query?.coin}
              onChange={coinChangeHandler}
            />
          </div>
          {selectedCoin === 'irt' ? <PayToman /> : <PayCoin coins={coins} selectedCoin={selectedCoin} />}
        </div>
      </div>
    </Container>
  )
}

function PageHeader({ router }) {
  return (
    <div className='flex flex-row items-center justify-between mb-10'>
      <Link href={`/user/${router.query.userid}/wallet`} className='flex flex-row items-center gap-3'>
        <img src='/images/arrowleft.png' alt='arrow-left' className='w-8 h-8 object-contain' />
        <span>برگشت به کیف پول</span>
      </Link>
      <span className='bg-primary py-3 px-6 rounded-full text-2xl font-bold'>واریز آنلاین</span>
    </div>
  )
}

function PayToman() {
  const valueInputRef = useRef()
  const valueClickHandler = ev => {
    const value = ev.target.innerHTML
    valueInputRef.current.value = value
  }

  return (
    <Fragment>
      <div>
        <h4 className='text-xl font-bold'>مبلغ واریزی به تومان</h4>
        <div className='flex flex-row items-center border-solid border-b-white border-b'>
          <input ref={valueInputRef} type='text' className='py-2' />
          <span>تومان</span>
        </div>
        <div className='flex flex-row flex-wrap gap-3 py-2'>
          <button onClick={valueClickHandler} className='bg-blue-500 py-1 px-3 rounded-full'>
            2000000
          </button>
          <button onClick={valueClickHandler} className='bg-blue-500 py-1 px-3 rounded-full'>
            5000000
          </button>
          <button onClick={valueClickHandler} className='bg-blue-500 py-1 px-3 rounded-full'>
            10000000
          </button>
          <button onClick={valueClickHandler} className='bg-blue-500 py-1 px-3 rounded-full'>
            50000000
          </button>
        </div>
      </div>
      <div className='flex flex-row justify-start items-start gap-2'>
        <div className='w-3 translate-y-1/2 aspect-square rounded-full bg-primary'></div>
        <p className='max-w-md'>
          لطفا توجه داشته باشید که واریز وجه فقط باید از کارت های بانکی که به نام شما است و تایید شده می باشد استفاده
          کنید. در غیر این صورت کیف پول شما شارژ نخواهد شد.
        </p>
      </div>
      <div>
        <Link className='button text-2xl font-bold px-8' href='#'>
          انتقال به درگاه پرداخت
        </Link>
      </div>
    </Fragment>
  )
}

function PayCoin({ coins = [], selectedCoin }) {
  const coinTitle = coins.find(coin => coin.value === selectedCoin)?.title
  const payChannels = [
    { title: 'شبکه واریزی یک', value: 'paych1' },
    { title: 'شبکه واریزی دو', value: 'paych2' },
    { title: 'شبکه واریزی سه', value: 'paych3' },
  ]

  return (
    <Fragment>
      <div>
        <h4 className='text-xl font-bold'>برای واریز {coinTitle} ابتدا شبکه واریزی تا انتخاب نمایید.</h4>
        <SelectBox className='border-solid border-b-white border-b' items={payChannels} />
      </div>
      <div className='flex flex-row justify-start items-start gap-2'>
        <div className='w-3 translate-y-1/2 aspect-square rounded-full bg-primary'></div>
        <p className='max-w-md'>
          لطفا دقت داشته باشید واریز هر ارز دیگری به این آدرس به جز {coinTitle} موجب از دست رفتن دارایی شما می شود.
        </p>
      </div>
      <div className='flex flex-row items-stretch border-solid border-b-white border-b py-0.5'>
        <input type='text' disabled={true} className='grow py-1' value={'sahfhdsajkfjkdfgdhfghdjkfkljdafj'} />
        <img src='/images/copyicon.png' alt='copy' className='h-full w-6 object-contain shrink-0' />
      </div>
    </Fragment>
  )
}

Deposite.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='واریز آنلاین' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
export async function getStaticPaths() {
  return {
    paths: [{ params: { userid: 'saman' } }],
    fallback: false
  }
}