import Link from 'next/link'
import { useRouter } from 'next/router'
import Container from '../../../../components/ui/Container'
import DefaultLayout from '../../../../layouts/DefaultLayout'
import InputSelect from '../../../../components/ui/InputSelect'
import { useState } from 'react'
import SelectBox from '../../../../components/ui/SelectBox'
import createStaticPropsWithNavData from "../../../../api/helpers/navdata";

export default function Withdraw() {
  const router = useRouter()
  const shebaID = [
    { title: 'IR-24312-3214312-3241234', value: 'shen234' },
    { title: 'IR-223412-14312-3241234', value: 'w34sdf' },
    { title: 'IR-56312-3212344312-3241234', value: '234s' },
  ]

  return (
    <Container>
      <PageHeader router={router} />
      <div className='flex flex-col lg:flex-row items-stretch lg:items-center w-full gap-8'>
        <div className='w-full md:w-1/2 lg:w-5/12 shrink-0'>
          <img
            src='/images/withdrawlogo.png'
            alt='withdraw-logo'
            className='w-full'
          />
        </div>
        <div className='grow flex flex-col items-stretch gap-8' dir='rtl'>
          <div>
            <h4 className='text-2xl font-bold'>مبلغ برداشت به تومان</h4>
            <div className='flex flex-row items-center border-solid border-b-white border-b '>
              <input type='text' className='grow py-1' />
              <span>تومان</span>
            </div>
            <div className='text-primary-light py-2'>
              <p>موجودی: 0 تومان</p>
              <p>کارمزد: 0 تومان</p>
              <p>مقدار برداشت نهایی: 0 تومان</p>
            </div>
          </div>
          <div>
            <h4 className='text-2xl font-bold'>شماره شبا</h4>
            <InputSelect
              items={shebaID}
              className='border-solid border-b-white border-b mb-4'
            />
            <p>
              سقف برداشت برای هر شماره شبا 100 میلیون تومان می باشد. برای برداشت
              با مبالغ بالاتر، لطفا درخواست برداشت وجه را در روز های بعد ثبت
              کنید.
            </p>
          </div>
          <button className='button px-8 text-2xl font-bold'>درخواست برداشت وجه</button>
        </div>
      </div>
    </Container>
  )
}

Withdraw.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='برداشت آنلاین' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
export async function getStaticPaths() {
  return {
    paths: [{ params: { userid: 'saman' } }],
    fallback: false
  }
}

function PageHeader({ router }) {
  return (
    <div className='flex flex-row items-center justify-between mb-10'>
      <Link
        href={`/user/${router.query.userid}/wallet`}
        className='flex flex-row items-center gap-3'>
        <img
          src='/images/arrowleft.png'
          alt='arrow-left'
          className='w-8 h-8 object-contain'
        />
        <span>برگشت به کیف پول</span>
      </Link>
      <span className='bg-custom-brown py-3 px-6 rounded-full text-2xl font-bold'>
        برداشت آنلاین
      </span>
    </div>
  )
}
