import Link from 'next/link'
import { useState } from 'react'
import Container from '../../../../components/ui/Container'
import DefaultLayout from '../../../../layouts/DefaultLayout'
import createStaticPropsWithNavData from '../../../../api/helpers/navdata'

export default function Wallet() {
  const [unit, setUnit] = useState('toman')
  const walletBallanceTitle = unit === 'toman' ? 'تومن' : 'تتر'
  const walletBallance = unit === 'toman' ? 3000 * 34 : 3000

  const unitChangeHandler = selectedUnit => {
    setUnit(selectedUnit)
  }

  return (
    <Container>
      <div className='flex flex-col items-center lg:flex-row gap-4 pb-4'>
        <div className='relative w-full md:w-1/2 lg:w-5/12 shrink-0'>
          <img src='/images/walletlogo.png' alt='wallet-logo' className='w-full' />
          <p
            dir='rtl'
            className='absolute w-max top-[15%] left-1/2 -translate-x-1/2 text-black font-bold bg-[#b1d2de] border-solid border-[#e0e0e0] border-4 p-2 rounded-xl'>
            <span className='font-sans'>{walletBallance}</span> <span className='text-xl'>{walletBallanceTitle}</span>
          </p>
        </div>
        <div dir='rtl' className='flex flex-col items-center gap-2 lg:gap-4 grow w-full lg:w-auto text-2xl'>
          <button className='flex flex-row justify-center items-center gap-2 w-full max-w-sm p-2 bg-primary rounded-full'>
            <span className='w-7 h-7 block'>
              <img src='/images/arrowdown.png' alt='arrowdown' className='w-full h-full' />
            </span>
            <span className='w-[6ch]'>واریز</span>
          </button>
          <button className='flex flex-row justify-center items-center gap-2 w-full max-w-sm p-2 bg-custom-brown rounded-full'>
            <span className='w-7 h-7 block'>
              <img src='/images/arrowup.png' alt='arrowup' className='w-full h-full' />
            </span>
            <span className='w-[6ch]'>برداشت</span>
          </button>
        </div>
      </div>
      <div dir='rtl'>
        <SearchBox />
        <div className='flex flex-row items-center justify-between mb-4'>
          <MyCurrencies />
          <UnitSwitch unit={unit} onUnitChange={unitChangeHandler} />
        </div>
        <CoinsTable>
          <CoinRow
            title='تومان'
            symbol='IRT'
            imgSrc='/images/coins/tomanicon.png'
            allBalance={30}
            collectableBalance={20}
            unit={unit}
            showSecondPrice={false}
            price={30}
          />
          <CoinRow
            title='تومان'
            symbol='IRT'
            imgSrc='/images/coins/tomanicon.png'
            allBalance={30}
            collectableBalance={20}
            unit={unit}
            price={30}
            tradable
          />
          <CoinRow
            title='تومان'
            symbol='IRT'
            imgSrc='/images/coins/tomanicon.png'
            allBalance={30}
            collectableBalance={20}
            unit={unit}
            price={30}
            tradable
          />
          <CoinRow
            title='تومان'
            symbol='IRT'
            imgSrc='/images/coins/tomanicon.png'
            allBalance={30}
            collectableBalance={20}
            unit={unit}
            price={30}
            tradable
          />
        </CoinsTable>
        <button className='button block mx-auto text-xl'>نمایش ادامه ارز ها</button>
      </div>
    </Container>
  )
}

Wallet.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='کیف پول' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
export async function getStaticPaths() {
  return {
    paths: [{ params: { userid: 'saman' } }],
    fallback: false
  }
}

// ------------------ Search Box ------------------ //
function SearchBox() {
  return (
    <div className='flex flex-row items-stretch max-w-xs w-full border-solid border-white border p-2 rounded-full mb-4'>
      <input type='text' placeholder='جست و جوی نام ارز' />
      <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20' fill='currentColor' className='w-5 h-5'>
        <path
          fillRule='evenodd'
          d='M9 3.5a5.5 5.5 0 100 11 5.5 5.5 0 000-11zM2 9a7 7 0 1112.452 4.391l3.328 3.329a.75.75 0 11-1.06 1.06l-3.329-3.328A7 7 0 012 9z'
          clipRule='evenodd'
        />
      </svg>
    </div>
  )
}

// ------------------------------------- Coins Table ------------------------------------- //
function CoinsTable({ children }) {
  return (
    <div className='overflow-x-auto mb-8'>
      <table className='min-w-full table-auto'>
        <thead>
          <tr>
            <th className='p-4 text-xl'>نام ارز</th>
            <th className='p-4 text-xl'>کل موجودی</th>
            <th className='p-4 text-xl'>موجودی قابل برداشت</th>
            <th className='p-4 text-xl'>عملیات ها</th>
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  )
}

function CoinRow({
  title,
  imgSrc,
  allBalance = 0,
  collectableBalance = 0,
  price = 1,
  unit = 'toman',
  tomanPrice = 35,
  showSecondPrice = true,
  symbol,
  tradable,
}) {
  const allSecondPrice = unit === 'toman' ? allBalance * price * tomanPrice : allBalance * price
  const secondCollectableBalance =
    unit === 'toman' ? collectableBalance * price * tomanPrice : collectableBalance * price
  const unitName = unit === 'toman' ? 'تومان' : 'تتر'

  return (
    <tr className='border-solid border-b-white border-b'>
      <td className='p-4'>
        <div className='flex flex-row items-center gap-4'>
          <span className='w-8'>
            <img src={imgSrc} alt='coin_logo' className='w-full' />
          </span>
          <span>
            {title} ( {symbol} )
          </span>
        </div>
      </td>
      <td className='p-4'>
        <div className='flex flex-col text-right'>
          <span dir='ltr'>
            {allBalance} {symbol}
          </span>
          {showSecondPrice && (
            <span>
              {allSecondPrice} {unitName}
            </span>
          )}
        </div>
      </td>
      <td className='p-4'>
        <div className='flex flex-col text-right'>
          <span dir='ltr'>
            {collectableBalance} {symbol}
          </span>
          {showSecondPrice && (
            <span>
              {secondCollectableBalance} {unitName}
            </span>
          )}
        </div>
      </td>
      <td className='w-0 p-4'>
        <div className='flex flex-row justify-start gap-2'>
          <Link href='#' className='py-1 px-4 rounded-full bg-primary'>
            واریز
          </Link>
          <Link href='#' className='py-1 px-4 rounded-full bg-custom-brown'>
            برداشت
          </Link>
          {tradable && (
            <Link href='#' className='py-1 px-4 rounded-full bg-blue-500'>
              معامله
            </Link>
          )}
        </div>
      </td>
    </tr>
  )
}

// ------------------------------------ Switch ---------------------------- //

function UnitSwitch({ unit, onUnitChange }) {
  const tomanStyle = unit === 'toman' ? 'bg-primary' : ''
  const teterStyle = unit === 'teter' ? 'bg-primary' : ''

  return (
    <span className='flex flex-row text-lg'>
      <button
        className={`py-1 px-4 rounded-full ${tomanStyle} transition-colors duration-300`}
        onClick={() => onUnitChange('toman')}>
        تومان
      </button>
      <button
        className={`py-1 px-4 rounded-full ${teterStyle} transition-colors duration-300`}
        onClick={() => onUnitChange('teter')}>
        تتر
      </button>
    </span>
  )
}

function MyCurrencies({ onChange = () => {} }) {
  return (
    <div className='flex flex-row items-center w-full max-w-xs justify-start gap-2 text-lg'>
      <label>
        <input type='checkbox' className='hidden peer' onChange={onChange} />
        <span className='block w-4 h-4 rounded-full border-solid border-white border-2 peer-checked:bg-blue-500'></span>
      </label>
      <span>فقط ارز های من</span>
    </div>
  )
}
