import DefaultLayout from '../../../../layouts/DefaultLayout'
import navLinks from '../../../../assets/data/headerLinks.json'
import Container from '../../../../components/ui/Container'
import Link from 'next/link'
import { useState } from 'react'
import useChartConfig from '../../../../hooks/useChartConfig'
import dynamic from 'next/dynamic'

const Dashboard = () => {
  const [ordersListUnit, setOrdersListUnit] = useState('usdt') // this will be 'usdt' || 'irt'
  const [currenciesUnit, setCurrenciesUnit] = useState('usdt') // this will be 'usdt' || 'irt'

  return (
    <Container dir='rtl'>
      <div className='w-full flex flex-col justify-start items-stretch lg:flex-row lg:items-start text-neutral-800 gap-4'>
        <div className='shrink-0 w-full lg:w-1/4 bg-gradient-to-br from-black/90 to-black/70 p-4 rounded-3xl'>
          <ul className='flex flex-col items-stretch text-gray-100 gap-2'>
            <SidebarLink
              img='/images/dashboard/dashboard_3d.png'
              imgAlt='dashboard icon'>
              داشبورد
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/property_3d.png'
              imgAlt='property icon'>
              دارایی
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/make_order_3d.png'
              imgAlt='make order icon'>
              ثبت سفارش
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/order_list_3d.png'
              imgAlt='order list icon'>
              لیست سفارشات
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/wallet_3d.png'
              imgAlt='wallet icon'>
              کیف پول
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/transition_list_3d.png'
              imgAlt='transition icon'>
              لیست تراکنش ها
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/bank_account.png'
              imgAlt='bank account icon'>
              حساب بانکی
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/user_account_3d.png'
              imgAlt='user account icon'>
              حساب کاربری
            </SidebarLink>

            <SidebarLink img='/images/dashboard/auth_3d.png' imgAlt='auth icon'>
              احراز هویت
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/share_3d.png'
              imgAlt='share icon'>
              معرفی به دوستان
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/support_3d.png'
              imgAlt='support icon'>
              پشتیبانی
            </SidebarLink>

            <SidebarLink img='/images/dashboard/faq_3d.png' imgAlt='faq icon'>
              سوالات متداول
            </SidebarLink>

            <SidebarLink
              img='/images/dashboard/logout_3d.png'
              imgAlt='logout icon'>
              خروج
            </SidebarLink>
          </ul>
        </div>
        <div className='flex flex-col items-stretch overflow-hidden w-full lg:w-auto lg:grow'>
          <ul className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4'>
            <StatusGridItem
              img='/images/dashboard/orders_count_3d.png'
              imgAlt='orders count'
              count={4}>
              تعداد کل سفارشات
            </StatusGridItem>

            <StatusGridItem
              img='/images/dashboard/all_orders_price.png'
              imgAlt='orders price'
              count={4}>
              مبلغ کل سفارشات
            </StatusGridItem>

            <StatusGridItem
              img='/images/dashboard/buy_order_count_3d.png'
              imgAlt='buy order'
              count={1}>
              کل سفارشات خرید
            </StatusGridItem>

            <StatusGridItem
              img='/images/dashboard/sell_order_count_3d.png'
              imgAlt='sell order'
              count={4}>
              کل سفارشات فروش
            </StatusGridItem>
          </ul>

          <div className='bg-gradient-to-br from-black/90 to-black/60 py-4 px-6 rounded-3xl text-gray-200 mb-4'>
            <div className='flex flex-row items-center justify-between mb-6'>
              <div className='flex flex-row items-center gap-2'>
                <img
                  className='w-9 h-9 object-contain'
                  src='/images/dashboard/order_list_3d.png'
                  alt='order list icon'
                />
                <p className='text-3xl font-bold'>لیست سفارشات</p>
              </div>
              <div className='flex flex-row items-center inline-block bg-white rounded-full'>
                <button
                  onClick={() => setOrdersListUnit('irt')}
                  className={`${
                    ordersListUnit === 'irt'
                      ? 'bg-primary text-white'
                      : 'text-black'
                  } rounded-full px-3 py-0.5`}>
                  تومان
                </button>
                <button
                  onClick={() => setOrdersListUnit('usdt')}
                  className={`${
                    ordersListUnit === 'usdt'
                      ? 'bg-primary text-white'
                      : 'text-black'
                  } rounded-full px-4 py-0.5`}>
                  تتر
                </button>
              </div>
            </div>
            <div className='w-full overflow-x-auto custom-scroll mb-4'>
              <table className='min-w-full whitespace-nowrap'>
                <thead className='text-xl'>
                  <tr>
                    <th className='py-2 px-4'>نام ارز</th>
                    <th className='py-2 px-4'>
                      مقدار ( {ordersListUnit === 'irt' ? 'تومان' : 'تتر'} )
                    </th>
                    <th className='py-2 px-4'>تعداد</th>
                    <th className='py-2 px-4'>نحوه پرداخت</th>
                    <th className='py-2 px-4'>تاریخ</th>
                    <th className='py-2 px-4'>وضعیت</th>
                  </tr>
                </thead>
                <tbody>
                  <OrderListItem
                    count={3}
                    value={5}
                    statusColor='fail'
                    name='تتر'
                    method='کیف پول ریالی'
                    status='در انتظار تایید'
                    coinImg='/images/coins/tetericon.png'
                    date='1401/11/25'
                    symbol='USDT'
                    unit={ordersListUnit}
                  />

                  <OrderListItem
                    count={13}
                    value={1}
                    statusColor='success'
                    name='تتر'
                    method='کیف پول ریالی'
                    status='تایید شده'
                    coinImg='/images/coins/tetericon.png'
                    date='1401/11/25'
                    symbol='USDT'
                    unit={ordersListUnit}
                  />
                </tbody>
              </table>
            </div>
            <div className='flex flex-row items-center justify-end gap-1.5'>
              <button>
                <img
                  src='/images/dashboard/right_arrow.png'
                  alt='right arrow'
                />
              </button>
              <button>
                <img src='/images/dashboard/left_arrow.png' alt='right arrow' />
              </button>
            </div>
          </div>

          <div className='bg-gradient-to-br from-black/90 to-black/60 py-4 px-6 rounded-3xl text-gray-200 mb-4'>
            <div className='flex flex-row items-center justify-between mb-6'>
              <div className='flex flex-row items-center gap-2'>
                <img
                  className='w-9 h-9 object-contain'
                  src='/images/dashboard/cryptocurrencies.png'
                  alt='order list icon'
                />
                <p className='text-3xl font-bold'>رمز ارز ها</p>
              </div>
              <div className='flex flex-row items-center inline-block bg-white rounded-full'>
                <button
                  onClick={() => setCurrenciesUnit('irt')}
                  className={`${
                    currenciesUnit === 'irt'
                      ? 'bg-primary text-white'
                      : 'text-black'
                  } rounded-full px-3 py-0.5`}>
                  تومان
                </button>
                <button
                  onClick={() => setCurrenciesUnit('usdt')}
                  className={`${
                    currenciesUnit === 'usdt'
                      ? 'bg-primary text-white'
                      : 'text-black'
                  } rounded-full px-4 py-0.5`}>
                  تتر
                </button>
              </div>
            </div>
            <div className='w-full overflow-x-auto custom-scroll'>
              <table className='min-w-full whitespace-nowrap'>
                <thead className='text-xl'>
                  <tr>
                    <th className='px-4 py-2'>نام ارز</th>
                    <th className='px-4 py-2'>قیمت</th>
                    <th className='px-4 py-2'>تغییرات</th>
                    <th className='px-4 py-2'>نمودار 24 ساعت</th>
                    <th className='px-4 py-2'>موجودی</th>
                    <th className='px-4 py-2'>عملیات ها</th>
                  </tr>
                </thead>
                <tbody>
                  <CurrencyRow
                    changes={-0.234}
                    unitPrice={324222}
                    unit={currenciesUnit}
                    coinImg='/images/coins/bitcoinicon.png'
                    name='بیت کوین'
                    ownValue={0}
                    priceValues={[234, 432, 100, 23, 50]}
                    symbol='BTC'
                  />
                  <CurrencyRow
                    changes={3.4}
                    unitPrice={324222}
                    unit={currenciesUnit}
                    coinImg='/images/coins/bitcoinicon.png'
                    name='بیت کوین'
                    ownValue={0}
                    priceValues={[234, 432, 100, 23, 50]}
                    symbol='BTC'
                  />
                  <CurrencyRow
                    changes={0.234}
                    unitPrice={324222}
                    unit={currenciesUnit}
                    coinImg='/images/coins/bitcoinicon.png'
                    name='بیت کوین'
                    ownValue={0}
                    priceValues={[234, 432, 100, 23, 50]}
                    symbol='BTC'
                  />
                </tbody>
              </table>
            </div>
            <div className='flex flex-row items-center justify-end gap-1.5'>
              <button>
                <img
                  src='/images/dashboard/right_arrow.png'
                  alt='right arrow'
                />
              </button>
              <button>
                <img src='/images/dashboard/left_arrow.png' alt='right arrow' />
              </button>
            </div>
          </div>

          <div className='bg-gradient-to-br from-black/90 to-black/60 py-4 px-6 rounded-3xl text-gray-200 mb-4'>
            <div className='flex flex-row items-center justify-between mb-6'>
              <div className='flex flex-row items-center gap-2'>
                <img
                  className='w-8 h-8 object-contain'
                  src='/images/dashboard/bank_account.png'
                  alt='order list icon'
                />
                <p className='text-3xl font-bold'>کارت های بانکی</p>
              </div>
              <img
                src='/images/dashboard/green_shield.png'
                alt='green shield'
              />
            </div>

            <div className='w-full overflow-x-auto custom-scroll'>
              <table className='min-w-full whitespace-nowrap'>
                <thead className='text-xl'>
                  <tr>
                    <th className='px-4 py-2'>نام بانک</th>
                    <th className='px-4 py-2'>شماره کارت</th>
                    <th className='px-4 py-2'>شماره شبا</th>
                    <th className='px-4 py-2'>وضعیت</th>
                  </tr>
                </thead>
                <tbody>
                  <BankTableRow
                    bankName='بانک سامان'
                    bankCard='6037************'
                    sheba='IR********************'
                    status='تایید شده'
                    color='success'
                  />
                  <BankTableRow
                    bankName='بانک اقتصاد نوین'
                    bankCard='6037************'
                    sheba='IR********************'
                    status='در انتظار تایید'
                    color='fail'
                  />
                </tbody>
              </table>
            </div>
          </div>

          <div className='bg-gradient-to-br from-black/90 to-black/60 py-4 px-6 rounded-3xl text-gray-200'>
            <div className='flex flex-row items-center gap-2'>
              <img
                className='w-8 h-8 object-contain'
                src='/images/dashboard/notifications.png'
                alt='order list icon'
              />
              <p className='text-3xl font-bold'>اعلامیه ها</p>
            </div>
            <div className='py-6'>
              <p className='text-center text-2xl'>
                شما هیچ اعلان جدیدی ندارید.
              </p>
            </div>
            <div className='flex flex-row items-center justify-end gap-1.5'>
              <button>
                <img
                  src='/images/dashboard/right_arrow.png'
                  alt='right arrow'
                />
              </button>
              <button>
                <img src='/images/dashboard/left_arrow.png' alt='right arrow' />
              </button>
            </div>
          </div>
        </div>
      </div>
    </Container>
  )
}

Dashboard.getLayout = page => (
  <DefaultLayout
    navLinks={navLinks.links}
    navbar
    footer
    theme={'light'}
    title={'داشبورد'}>
    {page}
  </DefaultLayout>
)

function SidebarLink({ img, imgAlt, href = '/', children }) {
  return (
    <li>
      <Link className='block flex flex-row items-center gap-3' href={href}>
        <img className='w-10 h-10 object-contain' src={img} alt={imgAlt} />
        <span className='font-bold text-lg truncate'>{children}</span>
      </Link>
    </li>
  )
}

function StatusGridItem({ img, imgAlt = '', children, count = 0 }) {
  return (
    <li className='w-full bg-gradient-to-br from-black/90 to-black/70 p-4 text-gray-100 rounded-3xl'>
      <img className='w-14 h-14 object-contain' src={img} alt={imgAlt} />
      <h4 className='truncate font-bold text-lg'>{children}</h4>
      <p className='font-sans'>{count}</p>
    </li>
  )
}

function BankTableRow({
  bankName = '',
  bankCard = '',
  sheba = '',
  status = '',
  color = 'success',
}) {
  const statusColor =
    color === 'success'
      ? 'bg-primary'
      : color === 'fail'
      ? 'bg-custom-brown'
      : ''

  return (
    <tr>
      <td className='px-4 py-2'>{bankName}</td>
      <td className='font-sans text-right px-4 py-2' dir='ltr'>
        {bankCard}
      </td>
      <td className='font-sans text-right px-4 py-2' dir='ltr'>
        {sheba}
      </td>
      <td className='px-4 py-2'>
        <span
          className={`${statusColor} text-white text-sm px-2 py-0.5 rounded-full`}>
          {status}
        </span>
      </td>
    </tr>
  )
}

function OrderListItem({
  coinImg = '/images/coins/tetericon.png',
  name = '',
  value = 0,
  count = 0,
  symbol = 'USDT',
  method = 'نا مشخص',
  date = '1401/11/25',
  status = 'نا مشخص',
  statusColor = 'success',
  unit = 'irt',
  unitPrice = 34000,
}) {
  const statusBg = statusColor === 'success' ? 'bg-primary' : 'bg-custom-brown'
  const calculatedValue = unit === 'irt' ? value * unitPrice : value

  return (
    <tr>
      <td className='py-2 px-4'>
        <div className='flex items-center gap-2'>
          <span className='inline-block w-6 h-6'>
            <img className='w-full h-full' src={coinImg} alt={name} />
          </span>
          <span>{name}</span>
        </div>
      </td>
      <td className='py-2 px-4 font-sans'>{calculatedValue}</td>
      <td className='py-2 px-4 font-sans text-right' dir='ltr'>
        {count} {symbol}
      </td>
      <td className='py-2 px-4'>{method}</td>
      <td className='py-2 px-4'>{date}</td>
      <td className='py-2 px-4'>
        <span
          className={`${statusBg} px-2 py-0.5 rounded-full text-sm text-white`}>
          {status}
        </span>
      </td>
    </tr>
  )
}

function CurrencyRow({
  coinImg = '/images/coins/tetericon.png',
  name = '',
  ownValue = 0,
  symbol = 'USDT',
  unit = 'irt',
  unitPrice = 5,
  irtPrice = 43000,
  changes = 0,
  priceValues = [0, 1],
}) {
  const Chart = dynamic(() => import('react-apexcharts'), { ssr: false })
  const { series, config } = useChartConfig(priceValues, unitPrice, unit, 'irt')

  const changesColor = changes < 0 ? 'text-red-500' : 'text-green-400'
  const calculatedUnitPrice = unit === 'irt' ? unitPrice * irtPrice : unitPrice

  return (
    <tr>
      <td className='py-2 px-4'>
        <div className='flex items-center gap-2'>
          <span className='inline-block w-12 h-12'>
            <img className='w-full h-full' src={coinImg} alt={name} />
          </span>
          <span>
            {name} ( {symbol.toUpperCase()} )
          </span>
        </div>
      </td>
      <td className='py-2 px-4'>
        <span className='font-sans'>{calculatedUnitPrice}</span>
        <span> {unit === 'irt' ? 'تومان' : 'تتر'}</span>
      </td>
      <td
        className={`py-2 px-4 font-sans text-right ${changesColor}`}
        dir='ltr'>
        {changes}%
      </td>
      <td className='py-2 px-4 text-black' dir='ltr'>
        <Chart width={150} height={60} series={series} options={config} />
      </td>
      <td className='py-2 px-4 font-sans text-right' dir='ltr'>
        {ownValue} {symbol.toUpperCase()}
      </td>
      <td className='py-2 px-4'>
        <button className='bg-white text-black py-1 px-3 rounded-full font-bold text-sm'>
          <span className='text-primary'>خرید</span>
          <span> / </span>
          <span className='text-custom-brown'>فروش</span>
        </button>
      </td>
    </tr>
  )
}

export default Dashboard
