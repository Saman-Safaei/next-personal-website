import Link from 'next/link'
import { useRouter } from 'next/router'
import Container from '../../../../components/ui/Container'
import DefaultLayout from '../../../../layouts/DefaultLayout'
import InputSelect from '../../../../components/ui/InputSelect'
import { useState } from 'react'
import SelectBox from '../../../../components/ui/SelectBox'
import createStaticPropsWithNavData from "../../../../api/helpers/navdata";

export default function WithdrawCoin() {
  const router = useRouter()
  const coins = [
    { title: 'بیت کوین', value: 'btc' },
    { title: 'تتر', value: 'usdt' },
    { title: 'کاردانو', value: 'ada' },
  ]
  const channels = [
    { title: 'شبکه اول', value: 'ch1' },
    { title: 'شبکه دوم', value: 'ch2' },
  ]
  const [selectedCoin, setSelectedCoin] = useState()

  const coinChangeHandler = coinValue => {
    setSelectedCoin(coins.find(coin => coin.value === coinValue))
  }

  return (
    <Container>
      <PageHeader router={router} />
      <div className='flex flex-col lg:flex-row items-stretch lg:items-center w-full gap-8'>
        <div className='w-full md:w-1/2 lg:w-5/12 shrink-0'>
          <img
            src='/images/withdrawlogo.png'
            alt='withdraw-logo'
            className='w-full'
          />
        </div>
        <div className='grow flex flex-col items-stretch gap-8' dir='rtl'>
          <div>
            <p>
              <span className='w-2 h-2 inline-block rounded-full bg-primary' />{' '}
              کارمزد از مبلغ انتقال کسر خواهد شد.
            </p>
            <p>
              <span className='w-2 h-2 inline-block rounded-full bg-primary' />{' '}
              در صورتی که آدرس مقصد متعلق به کاربر صراف 24 باشد،انتقال به صورت
              مستقیم و آنی انجام می شود و بدون کارمزد خواهد بود.
            </p>
          </div>
          <div>
            <h4 className='text-xl font-bold'>انتخاب رمز ارز</h4>
            <InputSelect
              className='max-w-sm border-solid border-b-white border-b'
              items={coins}
              onChange={coinChangeHandler}
            />
          </div>
          <div className='border-solid border-b-white border-b'>
            <h4 className='text-xl font-bold'>انتخاب شبکه</h4>
            <SelectBox items={channels} />
          </div>
          <div>
            <h4 className='text-xl font-bold'>میزان برداشت {`${selectedCoin?.value}`.toUpperCase()}</h4>
            <input type="text" className='py-2 border-solid border-b-white border-b mb-4' />
            <div className='text-primary-light flex flex-row flex-wrap justify-between gap-6'>
              <p>موجودی: 0 {`${selectedCoin?.value || 0}`.toUpperCase()}</p>
              <p>کارمزد: 0 {`${selectedCoin?.value || 0}`.toUpperCase()}</p>
              <p>مقدار برداشت نهایی: 0 {`${selectedCoin?.value || 0}`.toUpperCase()}</p>
            </div>
          </div>
          <div className='border-solid border-b-white border-b'>
            <h4 className='text-xl font-bold'>آدرس کیف پول مقصد</h4>
            <input type="text" className='py-2' />
          </div>
          <button className='button px-8 text-2xl mx-auto'>درخواست برداشت</button>
        </div>
        
      </div>
    </Container>
  )
}

WithdrawCoin.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='برداشت آنلاین' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
export async function getStaticPaths() {
  return {
    paths: [{ params: { userid: 'saman' } }],
    fallback: false
  }
}

function PageHeader({ router }) {
  return (
    <div className='flex flex-row items-center justify-between mb-10'>
      <Link
        href={`/user/${router.query.userid}/wallet`}
        className='flex flex-row items-center gap-3'>
        <img
          src='/images/arrowleft.png'
          alt='arrow-left'
          className='w-8 h-8 object-contain'
        />
        <span>برگشت به کیف پول</span>
      </Link>
      <span className='bg-custom-brown py-3 px-6 rounded-full text-2xl font-bold'>
        برداشت آنلاین
      </span>
    </div>
  )
}
