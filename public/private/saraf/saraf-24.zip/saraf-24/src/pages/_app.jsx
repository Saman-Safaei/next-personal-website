import Head from 'next/head'
import { Fragment } from 'react'
import '../styles/globals.css'
import '@splidejs/react-splide/css/core';

export default function MyApp({ Component, pageProps }) {
  const getLayout = Component.getLayout || (page => page)

  return getLayout(
    <Fragment>
      <Head>
        <meta name='viewport' content='width=device-width, initial-scale=1.0' />
      </Head>
      <Component {...pageProps} />
    </Fragment>,
    pageProps
  )
}
