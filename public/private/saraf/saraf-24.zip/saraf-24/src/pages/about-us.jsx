import React from 'react'
import DefaultLayout from '../layouts/DefaultLayout'
import createStaticPropsWithNavData from '../api/helpers/navdata'
import Container from '../components/ui/Container'
import styles from '../styles/AboutUs.module.css'

export default function AboutUs(props) {
  return (
    <div className={styles.bg}>
      <Container dir='rtl'>
        <div className='flex flex-row items-center justify-between mb-8'>
          <h2 className='text-4xl px-8 py-4 bg-primary rounded-full'>درباره صراف 24</h2>
          <img className='w-20 h-20 object-contain' src='/images/about-us.png' alt='about-icon' />
        </div>
        <div className='relative grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-20 py-4 mb-4 lg:mb-16'>
          <div className='bg-gradient-to-br from-neutral-600 to-neutral-800 p-10 rounded-3xl'>
            <h3 className='text-4xl mb-2'>ما که هستیم ؟</h3>
            <p className='text-justify text-lg'>
              لورم ایپسوم یا طرح‌نما (به انگلیسی: Lorem ipsum) به متنی آزمایشی و بی‌معنی در صنعت چاپ، صفحه‌آرایی و طراحی
              گرافیک گفته می‌شود. طراح گرافیک از این متن به عنوان عنصری از ترکیب بندی برای پر کردن صفحه و ارایه اولیه شکل
              ظاهری و کلی طرح سفارش گرفته شده استفاده می نماید، تا از نظر گرافیکی نشانگر چگونگی نوع و اندازه فونت و ظاهر
              متن باشد. معمولا طراحان گرافیک برای صفحه‌آرایی، نخست از متن‌های آزمایشی و بی‌معنی استفاده می‌کنند تا صرفا
              به مشتری یا صاحب کار خود نشان دهند که صفحه طراحی یا صفحه بندی شده بعد از اینکه متن در آن قرار گیرد چگونه به
              نظر می‌رسد و قلم‌ها و اندازه‌بندی‌ها چگونه در نظر گرفته شده‌است.
            </p>
          </div>
          <img
            className='hidden lg:block w-52 absolute top-full left-1/2 translate-x-1/2 -translate-y-1/2 rotate-[-60deg] -z-10'
            src='/images/chain.png'
            alt='chain'
          />
          <img
            className='hidden lg:block w-44 absolute top-1/2 right-1/2 translate-x-1/2 -translate-y-1/2 -z-10'
            src='/images/chain.png'
            alt='chain'
          />
          <img
            className='hidden lg:block w-52 absolute top-full right-1/2 -translate-x-1/2 -translate-y-1/2 rotate-[60deg] -z-10'
            src='/images/chain.png'
            alt='chain'
          />
          <div className='bg-gradient-to-br from-neutral-600 to-neutral-800 p-10 rounded-3xl'>
            <h3 className='text-4xl mb-2'>چه کار میکنیم ؟</h3>
            <p className='text-justify text-lg'>
              لورم ایپسوم یا طرح‌نما (به انگلیسی: Lorem ipsum) به متنی آزمایشی و بی‌معنی در صنعت چاپ، صفحه‌آرایی و طراحی
              گرافیک گفته می‌شود. طراح گرافیک از این متن به عنوان عنصری از ترکیب بندی برای پر کردن صفحه و ارایه اولیه شکل
              ظاهری و کلی طرح سفارش گرفته شده استفاده می نماید، تا از نظر گرافیکی نشانگر چگونگی نوع و اندازه فونت و ظاهر
              متن باشد. معمولا طراحان گرافیک برای صفحه‌آرایی، نخست از متن‌های آزمایشی و بی‌معنی استفاده می‌کنند تا صرفا
              به مشتری یا صاحب کار خود نشان دهند که صفحه طراحی یا صفحه بندی شده بعد از اینکه متن در آن قرار گیرد چگونه به
              نظر می‌رسد و قلم‌ها و اندازه‌بندی‌ها چگونه در نظر گرفته شده‌است.
            </p>
          </div>
        </div>
        <div className='bg-gradient-to-br from-neutral-600 to-neutral-800 p-10 rounded-3xl'>
          <h3 className='text-4xl mb-4'>چرا صراف 24 ؟</h3>
          <p className='flex flex-col lg:flex-row gap-4 text-lg'>
            <span>
              لورم ایپسوم یا طرح‌نما (به انگلیسی: Lorem ipsum) به متنی آزمایشی و بی‌معنی در صنعت چاپ، صفحه‌آرایی و طراحی
              گرافیک گفته می‌شود. طراح گرافیک از این متن به عنوان عنصری از ترکیب بندی برای پر کردن صفحه و ارایه اولیه شکل
              ظاهری و کلی طرح سفارش گرفته شده استفاده می نماید،
              <br />
              <br />
              لورم ایپسوم یا طرح‌نما (به انگلیسی: Lorem ipsum) به متنی آزمایشی و بی‌معنی در صنعت چاپ، صفحه‌آرایی و طراحی
              گرافیک گفته می‌شود. طراح گرافیک از این متن به عنوان عنصری از ترکیب بندی برای پر کردن صفحه و ارایه اولیه شکل
              ظاهری و کلی طرح سفارش گرفته شده استفاده می نماید،
            </span>
            <span>
              لورم ایپسوم یا طرح‌نما (به انگلیسی: Lorem ipsum) به متنی آزمایشی و بی‌معنی در صنعت چاپ، صفحه‌آرایی و طراحی
              گرافیک گفته می‌شود. طراح گرافیک از این متن به عنوان عنصری از ترکیب بندی برای پر کردن صفحه و ارایه اولیه شکل
              ظاهری و کلی طرح سفارش گرفته شده استفاده می نماید،
              <br />
              <br />
              لورم ایپسوم یا طرح‌نما (به انگلیسی: Lorem ipsum) به متنی آزمایشی و بی‌معنی در صنعت چاپ، صفحه‌آرایی و طراحی
              گرافیک گفته می‌شود. طراح گرافیک از این متن به عنوان عنصری از ترکیب بندی برای پر کردن صفحه و ارایه اولیه شکل
              ظاهری و کلی طرح سفارش گرفته شده استفاده می نماید،
            </span>
          </p>
        </div>
      </Container>
    </div>
  )
}

AboutUs.getLayout = (page, props) => (
  <DefaultLayout navLinks={props.navLinks} title='درباره ما' navbar footer theme='light'>
    {page}
  </DefaultLayout>
)
export const getStaticProps = createStaticPropsWithNavData()
