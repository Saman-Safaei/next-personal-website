import Link from 'next/link'
import Container from '../../components/ui/Container'
import IdentityProvider from '../../context/identity/IdentityProvider'
import DefaultLayout from '../../layouts/DefaultLayout'
import createStaticPropsWithNavData from '../../api/helpers/navdata'

export default function ConfirmBankAccount() {
  return (
    <Container dir='rtl'>
      <div className='flex flex-col lg:flex-row lg:items-center gap-8'>
        <div className='grow order-2 lg:order-1'>
          <div className='lg:max-w-sm ml-auto mb-14'>
            <h2 className='text-3xl font-bold mb-2 text-center lg:text-start'>مرحله سوم: حساب بانکی</h2>
            <p className='text-xl'>
              حداقل یک کارت بانکی وارد کنید. این کارت باید با نام شما باشد تا بتوانید واریز و برداشت انجام دهید.
            </p>
          </div>
          <div>
            <div className='grid grid-cols-1 md:grid-cols-2 gap-8 mb-14'>
              <div>
                <h4 className='text-lg'>شماره کارت</h4>
                <input className='block w-full p-2 border-solid border-b-white border-b' type='text' />
              </div>
              <div>
                <h4 className='text-lg'>شماره شبا</h4>
                <input className='block w-full p-2 border-solid border-b-white border-b' type='text' />
              </div>
            </div>
            <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
              <Link href='/auth/confirmCommitment' className='button w-full bg-custom-brown'>
                افزودن کارت بانکی
              </Link>
              <Link href='/auth/confirmCommitment' className='button w-full'>
                تایید
              </Link>
            </div>
          </div>
        </div>
        <div className='w-full md:w-1/2 md:mx-auto lg:w-5/12 lg:mx-0 shrink-0 order-1 lg:order-2 img-cover'>
          <img src='/images/confirmBank.png' alt='authlogo' className='w-full object-contain' />
        </div>
      </div>
    </Container>
  )
}

ConfirmBankAccount.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='اضافه کردن حساب بانکی' navLinks={props.navLinks}>
    <IdentityProvider>{page}</IdentityProvider>
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
