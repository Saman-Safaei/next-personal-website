import IdentityProvider from '../../context/identity/IdentityProvider'
import DefaultLayout from '../../layouts/DefaultLayout'
import Container from '../../components/ui/Container'
import Link from 'next/link'
import { useState } from 'react'
import SelectBox from '../../components/ui/SelectBox'
import createStaticPropsWithNavData from "../../api/helpers/navdata";

export default function ConfirmIdentity() {
  const [country, setCountry] = useState('iranian')
  const countryChangeHandler = value => {
    setCountry(value)
  }
  const identityCodeTitle = country === 'iranian' ? 'کد ملی' : 'شماره گذرنامه'
  const [filename, setFilename] = useState(null)

  const fileChangeHandler = ev => {
    setFilename(ev.target.files[0].name)
  }

  return (
    <Container dir='rtl'>
      <div className='flex flex-row justify-between items-center'>
        <h2 className='text-3xl font-bold text-center lg:text-start'>
          مرحله دوم: احراز هویت
        </h2>
        <SelectBox
          items={[
            { title: 'اتباع ایرانی', value: 'iranian' },
            { title: 'اتباع خارجی', value: 'outsider' },
          ]}
          onChange={countryChangeHandler}
        />
      </div>
      <div className='flex flex-col lg:flex-row gap-8 items-center'>
        <div className='grow order-2 lg:order-1'>
          <div className='grid grid-cols-1 md:grid-cols-2 grid-flow-dense gap-y-4 gap-x-8 mb-4'>
            <div>
              <h4>نام</h4>
              <input
                type='text'
                className='p-2 border-solid border-b-white border-b'
              />
            </div>
            <div>
              <h4>نام خانوادگی</h4>
              <input
                type='text'
                className='p-2 border-solid border-b-white border-b'
              />
            </div>
            <div>
              <h4>{identityCodeTitle}</h4>
              <input
                type='text'
                className='p-2 border-solid border-b-white border-b'
              />
            </div>
            <div>
              <h4>تاریخ تولد</h4>
              <input
                type='text'
                className='p-2 border-solid border-b-white border-b'
              />
            </div>
          </div>
          <div className='max-w-sm mx-auto'>
            <h4>جنسیت</h4>
            <SelectBox
              items={[
                { title: 'مذکر', value: 'male' },
                { title: 'مونث', value: 'female' },
              ]}
              className="mb-4"
            />
          </div>
          <div className='rounded-3xl bg-white text-gray-700 p-4 mb-8'>
            <img
              src='/images/imgPlaceholder.png'
              alt='img_placeholder'
              className='block mx-auto w-1/5'
            />
            <h3 className='text-3xl text-center font-bold mb-4'>
              {identityCodeTitle}
            </h3>
            <input
              id='fileInput'
              type='file'
              accept='image/png, image/jpeg'
              className='hidden'
              onChange={fileChangeHandler}
            />
            <label htmlFor='fileInput'>
              <span className='button block mx-auto px-8 mb-4'>
                {filename || 'بارگذاری تصویر'}
              </span>
            </label>
            <p className='text-lg text-center font-bold'>
              اطلاعات تکمیل شده در بالای صفحه باید مطابق با عکس کارت ملی باشد.
            </p>
          </div>
          <Link className='button block mx-auto text-xl' href='/auth/confirmBankAccount'>تایید</Link>
        </div>
        <div className='w-full md:w-1/2 md:mx-auto lg:w-5/12 lg:mx-0 shrink-0 order-1 lg:order-2 img-cover'>
          <img
            src='/images/confirmIdentity.png'
            alt='authlogo'
            className='w-full object-contain'
          />
        </div>
      </div>
    </Container>
  )
}

ConfirmIdentity.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='تایید هویت' navLinks={props.navLinks}>
    <IdentityProvider>{page}</IdentityProvider>
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()

