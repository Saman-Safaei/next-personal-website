import Link from 'next/link'
import IdentityProvider from '../../context/identity/IdentityProvider'
import DefaultLayout from '../../layouts/DefaultLayout'
import Container from '../../components/ui/Container'
import createStaticPropsWithNavData from "../../api/helpers/navdata";

export default function Identity(props) {
  return (
    <Container dir='rtl'>
      <div className='flex flex-col lg:flex-row gap-8'>
        <div className='grow order-2 lg:order-1'>
          <div className='lg:max-w-sm ml-auto mb-14'>
            <h2 className='text-3xl font-bold mb-2 text-center lg:text-start'>کاربر گرامی صراف 24</h2>
            <p className='text-2xl mb-8 text-center lg:text-justify'>
              طبق قوانین جمهوری اسلامی ایران، برای انجام معامله در پلتفرم صراف
              24 نیاز به احراز هویت شما وجود دارد.
            </p>
            <Link className='button block mx-auto px-8' href="/auth/confirmPhoneNumber">شروع احراز هویت</Link>
          </div>
          <h3 className='text-xl mb-2 font-bold'>بیشتر بدانید</h3>
          <p className='text-justify'>
            احراز هویت پایه‌ای با تایید شماره تلفن همراه، ارسال مدارک هویتی
            (کارت ملی)، ورود آدرس محل سکونت و تلفن ثابت و ارسال قبض تلفن جهت
            تایید آن‌ها، و ورود اطلاعات حساب و کارت بانکی صورت می‌گیرد. با
            انـجام ایـن سـطـح از احراز هویت می‌توانید اقدام به واریز وجه یا کوین،
            معامله و برداشت وجه/کوین بپردازید. همچنین لازم به توضیح است که با
            توجه به قوانین بانکی کشور و امکان بلوکه شدن وجوه واریز شده از
            کارت‌های بانکی مسروقه، کاربران جدید که به تازگی اقدام به ثبت و واریز
            وجه از طریق یک کارت بانکی می‌کنند، به مدت یک روز کاری امکان ثبت
            درخواست برداشت وجه را نخواهند داشت. این تاخیر صرفاً جهت تایید اصالت
            کارت بانکی بوده و در طول این مدت کاربران می‌توانند به هر میزان با
            وجه واریزی خود در سیستم معامله نمایند و آن را تبدیل به سایر ارزهای
            دیجیتال کنند و صرفا محدودیت در خارج کردن وجه واریزی به مدت یک روز
            کاری از سیستم صراف 24 است.
          </p>
        </div>
        <div className='w-full md:w-1/2 md:mx-auto lg:w-5/12 lg:mx-0 shrink-0 order-1 lg:order-2 img-cover'>
          <img
            src='/images/authstart.png'
            alt='authlogo'
            className='w-full object-contain'
          />
        </div>
      </div>
    </Container>
  )
}

Identity.getLayout = (page, props) => (
  <DefaultLayout navbar footer title="شروع احراز هویت" navLinks={props.navLinks}>
    <IdentityProvider>{page}</IdentityProvider>
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
