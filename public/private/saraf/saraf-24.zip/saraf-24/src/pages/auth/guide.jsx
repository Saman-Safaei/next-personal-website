import Container from '../../components/ui/Container'
import IdentityProvider from '../../context/identity/IdentityProvider'
import DefaultLayout from '../../layouts/DefaultLayout'
import createStaticPropsWithNavData from "../../api/helpers/navdata";

export default function Guide() {
  return (
    <Container dir='rtl'>
      <div className='grid grid-cols-1 md:grid-cols-2 text-xl gap-14'>
        <div>
          <h3 className='border-solid border-b-white border-b text-3xl font-bold text-center pb-2 mb-6'>
            راهنمای بارگذاری تصویر تهعد نامه
          </h3>
          <p className='text-justify mb-4'>
            مدارکی که هنگام گرفتن تصویر باید در دست گرفته شود، عبارتند از: کارت
            ملی و تصویر تعهد نامه
          </p>
          <h4>نکات مهم:</h4>
          <p className='text-justify'>
            در صورتی که کاربری کارت ملی هوشمند ندارد، می تواند از شناسنامه عکس
            دار و حاوی شماره ملی استفاده کند.
            <br /> همچنین می تواند از گواهی نامه رانندگی یا گذرنامه معتبر نیز
            استفاده کند.
            <br /> فرم تعهد نامه باید به صورت دست نوشته و روی کاغذ باشد و نام و
            نام خانوادگی، تاریخ و امضاء شخص در پایین فرم قید شود. مدارک باید
            کاملا خوانا و واضح باشند، عکس های تار و ناخوانا تایید نمی شوند.
            تصاویر نباید به صورت آینه ای یا معکوس باشند. کارت ملی را روی فرم
            تعهد نچسبانید. رعایت حجاب اسلامی برای بانوان الزامی می باشد.
          </p>
        </div>
        <div>
          <h4 className='text-2xl mb-2'>متن تهعد نامه:</h4>
          <p className='text-justify'>
            اینجانب (نام نام خانوادگی) به کد ملی (کـد مـلی) ضـمن مـطالعه و تایید
            قوانین استفاده از خدمات صراف 24، مـتـعهد می گـردم کـه حساب کاربری و
            مدارک خود را به منظور خرید و فروش بیت کوین و سایر ارزهای دیجیتال در
            اختیار سـایر افـراد قـرار نـدهم و بـه درخواست شخص ثالث از جمله افراد
            و گـروه هـای شـبکه های اجتماعی و غیره اقدام به ایجاد حساب کاربری و
            خرید و فروش نکنم. در صورت تخلف، مسئولیت آن را اعم از مالی، قـضایی و
            حـقوقی به صورت کامل بر عهده می گیرم.
            <br /> جهت احراز هویت در سایت صراف 24
            <br /> نام و نام خانوادگی
            <br /> امضاء
          </p>
        </div>
      </div>
    </Container>
  )
}

Guide.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='راهنمای تعهد نامه' navLinks={props.navLinks}>
    <IdentityProvider>{page}</IdentityProvider>
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
