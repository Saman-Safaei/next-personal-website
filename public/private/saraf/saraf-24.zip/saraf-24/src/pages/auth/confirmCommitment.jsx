import DefaultLayout from '../../layouts/DefaultLayout'
import Container from '../../components/ui/Container'
import IdentityProvider from '../../context/identity/IdentityProvider'
import { useState } from 'react'
import Link from 'next/link'
import createStaticPropsWithNavData from "../../api/helpers/navdata";

export default function ConfirmCommitment() {
  const [filename, setFilename] = useState('')
  const fileChangeHandler = ev => {
    setFilename(ev.target.files[0].name)
  }
  return (
    <Container dir='rtl'>
      <h2 className='text-3xl font-bold mb-4 text-center lg:text-start'>
        مرحله چهارم: تعهد نامه
      </h2>
      <div className='flex flex-col lg:flex-row lg:items-center gap-8'>
        <div className='grow order-2 lg:order-1'>
          <p className='text-xl mb-8'>
            برای تکمیل فرآیند احراز هویت، لطفا طبق{' '}
            <Link className='text-primary' href='/auth/guide'>
              راهنما
            </Link>{' '}
            عمل کنید.
          </p>
          <div className='rounded-3xl bg-white text-gray-700 p-4 mb-8'>
            <img
              src='/images/imgPlaceholder.png'
              alt='img_placeholder'
              className='block mx-auto w-1/5'
            />
            <h3 className='text-3xl text-center font-bold mb-4'>تعهد نامه</h3>
            <input
              id='fileInput'
              type='file'
              accept='image/png, image/jpeg'
              className='hidden'
              onChange={fileChangeHandler}
            />
            <label htmlFor='fileInput'>
              <span className='button block mx-auto px-8 mb-4'>
                {filename || 'بارگذاری تصویر'}
              </span>
            </label>
            <p className='text-lg text-center font-bold'>
              اطلاعات تکمیل شده در بالای صفحه باید مطابق با عکس کارت ملی باشد.
            </p>
          </div>
          <Link className='button block mx-auto px-8' href='#'>
            تایید
          </Link>
        </div>
        <div className='w-full md:w-1/2 md:mx-auto lg:w-5/12 lg:mx-0 shrink-0 order-1 lg:order-2 img-cover'>
          <img
            src='/images/confirmCommitment.png'
            alt='authlogo'
            className='w-full object-contain'
          />
        </div>
      </div>
    </Container>
  )
}

ConfirmCommitment.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='تعهد نامه' navLinks={props.navLinks}>
    <IdentityProvider>{page}</IdentityProvider>
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
