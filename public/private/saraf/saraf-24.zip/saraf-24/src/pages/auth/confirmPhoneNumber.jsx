import { useContext, useRef, useState } from 'react'
import Button from '../../components/ui/Button'
import Container from '../../components/ui/Container'
import IdentityProvider from '../../context/identity/IdentityProvider'
import DefaultLayout from '../../layouts/DefaultLayout'
import Counter from '../../components/ui/Counter'
import identitySlice from '../../context/identity/identitySlice'
import { useRouter } from 'next/router'
import createStaticPropsWithNavData from "../../api/helpers/navdata";

export default function ConfirmPhoneNumber() {
  const identityCtx = useContext(identitySlice)
  const router = useRouter()

  const [sendAgain, setSendAgain] = useState(false)
  const phoneNumberRef = useRef()
  const confirmCodeRef = useRef()

  const counterEndHandler = () => {
    setSendAgain(true)
  }

  const phoneEnterHandler = () => {
    identityCtx.setMobileNumber(phoneNumberRef.current.value)
  }
  const cofirmCodeHandler = () => {
    identityCtx.setMobileConfirmed(confirmCodeRef.current.value)
    if (confirmCodeRef.current.value.trim()) pushToNextStep()
  }

  const pushToNextStep = () => {
    router.push('/auth/confirmIdentity')
  }

  return (
    <Container dir='rtl'>
      <h2 className='text-3xl font-bold text-center lg:text-start mb-4'>
        مرحله اول: تایید شماره همراه
      </h2>
      <div className='flex flex-col lg:flex-row lg:items-center gap-8'>
        <div className='grow order-2 lg:order-1'>
          <div>
            <div className='py-8'>
              <h4 className='text-2xl font-bold'>شماره همراه</h4>
              <input
                placeholder='09020000000'
                ref={phoneNumberRef}
                type='text'
                className='border-solid border-b-white border-b w-full block p-2 !bg-transparent mb-6'
                defaultValue={identityCtx.mobileNum}
              />
              <Button
                onClick={phoneEnterHandler}
                className='block mx-auto font-bold'>
                ارسال کد
              </Button>
            </div>
            <div className='py-8'>
              <h4 className='text-2xl font-bold'>کد تایید</h4>
              <input
                placeholder='لطفا کد تایید پیامک شده را وارد کنید'
                ref={confirmCodeRef}
                type='text'
                className='border-solid border-b-white border-b w-full block p-2 !bg-transparent mb-6'
              />
              <Button
                className='block mx-auto font-bold mb-2'
                onClick={cofirmCodeHandler}>
                تایید
              </Button>
              <button
                type='button'
                disabled={!sendAgain}
                className='block mx-auto disabled:text-gray-400'>
                ارسال مجدد کد ({' '}
                <Counter startFrom={40} onEnd={counterEndHandler} /> ثانیه )
              </button>
            </div>
          </div>
        </div>
        <div className='w-full md:w-1/2 md:mx-auto lg:w-5/12 lg:mx-0 order-1 lg:order-2 img-cover'>
          <img
            src='/images/confirmPhoneNumber.png'
            alt='phone_logo'
            className='w-full object-contain'
          />
        </div>
      </div>
    </Container>
  )
}

ConfirmPhoneNumber.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='تایید شماره همراه' navLinks={props.navLinks}>
    <IdentityProvider>{page}</IdentityProvider>
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
