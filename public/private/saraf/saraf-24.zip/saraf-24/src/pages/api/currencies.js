export default function currencies(req, res) {
  res.json({
    data: [
      { title: 'تومان', img: '/images/coins/tomanicon.png', value: 'IRT', zarib: 1 },
      { title: 'بیت کوین', img: '/images/coins/bitcoinicon.png', value: 'BTC', zarib: 2300000 },
      { title: 'تتر', img: '/images/coins/tetericon.png', value: 'USDT', zarib: 350000 },
    ],
  })
}
