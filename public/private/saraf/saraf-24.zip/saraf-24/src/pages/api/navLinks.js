export default function navLinks(req, res) {
  res.json({
    links: [
      { title: 'کیف پول', url: '/user/saman/wallet' },
      { title: 'خرید', url: '/buy' },
      { title: 'بازار', url: '/market' },
      { title: 'معامله', url: '/trade' },
      { title: 'تماس با ما', url: '/contact-us' },
      { title: 'اپلیکیشن', url: '/application' },
    ],
  })
}
