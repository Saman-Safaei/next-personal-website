import DefaultLayout from '../layouts/DefaultLayout'
import Container from '../components/ui/Container'
import GreenDot from '../components/pages/application/GreenDot'
import DownloadLink from '../components/pages/application/DownloadLink'
import styles from '../styles/Application.module.css'
import createStaticPropsWithNavData from '../api/helpers/navdata'

export default function Application(props) {
  return (
    <div className={`${styles['wave-background']} py-10`}>
      <Container className='mt-10 text-black' dir='rtl'>
        <div className='flex flex-col-reverse md:flex-row items-center gap-6'>
          <div className='grow'>
            <h2 className='text-4xl mb-2'>دانلود اپلیکیشن صراف 24</h2>
            <h3 className='text-3xl'>یک بازار معاملاتی رمز ارز در موبایل شما</h3>
            <ul className='py-4 text-lg'>
              <li>
                <GreenDot /> امکان انجام معاملات با موبایل
              </li>
              <li>
                <GreenDot /> واریز و برداشت آنی
              </li>
              <li>
                <GreenDot /> پشتیبانی 24 ساعته
              </li>
            </ul>
            <ul>
              <DownloadLink link='https://google.com/' title='دانلود از کافه بازار' icon='/images/download/bazar.png' />
              <DownloadLink link='https://google.com/' title='دانلود مستقیم' icon='/images/download/direct.png' />
              <DownloadLink link='https://google.com/' title='دانلود از اپ استور' icon='/images/download/appstore.png' />
            </ul>
          </div>
          <div className='w-1/2 md:w-1/3 shrink-0'>
            <img className='w-full' src='/images/mobiles.png' alt='download' />
          </div>
        </div>
      </Container>
    </div>
  )
}

Application.getLayout = (page, props) => (
  <DefaultLayout title='دانلود اپلیکیشن' navbar footer theme='light' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

export const getStaticProps = createStaticPropsWithNavData()
