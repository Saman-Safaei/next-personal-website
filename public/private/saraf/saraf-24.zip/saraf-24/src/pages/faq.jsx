import Container from '../components/ui/Container'
import DefaultLayout from '../layouts/DefaultLayout'
import styles from '../styles/FAQ.module.css'
import createStaticPropsWithNavData from "../api/helpers/navdata";

export default function FAQ() {
  return (
    <Container dir='rtl'>
      <h3 className='mx-auto text-4xl text-white bg-primary w-fit px-6 py-4 rounded-full mb-8'>
        سوالات متداول
      </h3>
      <div className={`flex flex-col items-stretch gap-3 ${styles.faqbox} rounded-3xl p-6`}>
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
        <Collapse title="چگونه ثبت نام کنم ؟" desc="ابتدا روی دکمه ثبت نام کلیک کنید و سپس اطلاعات خود را تکمیل و مراحل احراز هویت رو سپری کنید." />
      </div>
    </Container>
  )
}

FAQ.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='سوالات پر تکرار' theme='light' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

function Collapse({ title, desc }) {
  return (
    <details className={`${styles.collapse} border-solid border-b-2 border-white/50 py-2`}>
      <summary className='flex flex-row justify-between items-center cursor-pointer select-none'>
        <span className='font-bold text-lg'>{title}</span>
        <svg
          xmlns='http://www.w3.org/2000/svg'
          fill='none'
          viewBox='0 0 24 24'
          strokeWidth={1.5}
          stroke='currentColor'
          className={`w-5 h-5`}>
          <path
            strokeLinecap='round'
            strokeLinejoin='round'
            d='M19.5 8.25l-7.5 7.5-7.5-7.5'
          />
        </svg>
      </summary>
      <p className='pt-2'>{desc}</p>
    </details>
  )
}

export const getStaticProps = createStaticPropsWithNavData()
