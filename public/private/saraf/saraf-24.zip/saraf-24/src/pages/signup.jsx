import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/router'

import DefaultLayout from '../layouts/DefaultLayout'
import Container from '../components/ui/Container'
import Counter from '../components/ui/Counter'
import RegisterCard from '../components/ui/RegisterCard'
import createStaticPropsWithNavData from "../api/helpers/navdata";

export default function SignUp() {
  const router = useRouter()
  const [level, setLevel] = useState(0)
  const [identifier, setIdentifier] = useState('')

  useEffect(() => {
    if (router.query.identifier) {
      setLevel(1)
      setIdentifier(router.query.identifier)
    } else setLevel(0)
  }, [router.query.identifier])

  const signUpSubmitHandler = identifyName => {
    router.push('?identifier=' + identifyName)
  }

  return (
    <Container>
      {level === 0 && <SignUpForm onSubmit={signUpSubmitHandler} />}
      {level === 1 && <ConfirmEmailOrPhone identifier={identifier} />}
    </Container>
  )
}

SignUp.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='ثبت نام در سایت' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

function SignUpForm({ onSubmit }) {
  const [errors, setErrors] = useState({
    identifierErr: '',
    passwordErr: '',
    rulesErr: false,
  })

  const resetErrors = () => {
    setErrors({ identifierErr: '', passwordErr: '', rulesErr: false })
  }

  const formSubmitHandler = ev => {
    ev.preventDefault()
    const identifier = ev.target.identifier.value
    const password = ev.target.password.value
    const rules = ev.target.rules.checked

    resetErrors()

    if (!identifier.trim())
      return setErrors(prevErrors => ({
        ...prevErrors,
        identifierErr: 'نام کاربری یا شماره همراه را وارد کنید',
      }))

    if (!password.trim() && password.trim().length < 8)
      return setErrors(prevErrors => ({
        ...prevErrors,
        passwordErr: 'رمز عبور باید بیشتر از 8 کاراکتر باشد',
      }))

    if (!rules)
      return setErrors(prevErrors => ({
        ...prevErrors,
        rulesErr: 'قوانین و مقررات را تایید نکرده اید',
      }))

    onSubmit(identifier)
  }

  return (
    <RegisterCard>
      <form
        onSubmit={formSubmitHandler}
        className='flex flex-col items-stretch gap-4'>
        <div>
          <label className='text-xl yekan-bold' htmlFor='identifier'>
            ایمیل یا شماره همراه
          </label>
          <input
            type='text'
            id='identifier'
            className='block w-full px-0.5 py-1.5 md:w-8/12 bg-transparent border-solid border-b border-white'
            placeholder='ایمیل یا شماره همراه خود را وارد نمایید'
          />
          <ErrorMSG message={errors.identifierErr} />
        </div>
        <div>
          <label className='text-xl yekan-bold' htmlFor='password'>
            رمز عبور
          </label>
          <input
            type='text'
            id='password'
            className='block w-full px-0.5 py-1.5 md:w-8/12 bg-transparent border-solid border-b border-white'
            placeholder='رمز عبور خود را وارد نمایید'
          />
          <ErrorMSG message={errors.passwordErr} />
        </div>
        <div className='flex flex-row gap-3 py-3'>
          <input className='w-auto' type='checkbox' id='rules' />
          <label htmlFor='rules'>با قوانین و مقررات صراف 24 موافقم</label>
        </div>
        <ErrorMSG message={errors.rulesErr} />
        <button className='bg-primary w-full md:w-8/12 rounded-full py-1'>
          تایید
        </button>
        <p className='w-full md:w-8/12 text-center'>
          عضو صراف 24 هستید ؟ <Link href='/signin'>ورود</Link>
        </p>
      </form>
    </RegisterCard>
  )
}

function ConfirmEmailOrPhone({ identifier }) {
  const [resend, setResend] = useState(false)

  const endHandler = () => {
    setResend(true)
  }

  return (
    <RegisterCard>
      <form className='flex flex-col items-stretch gap-4'>
        <div>
          <label className='text-xl yekan-bold' htmlFor='identifier'>
            ایمیل یا شماره همراه
          </label>
          <input
            type='text'
            id='identifier'
            className='block w-full px-0.5 py-1.5 md:w-8/12 bg-transparent border-solid border-b border-white'
            placeholder='ایمیل یا شماره همراه خود را وارد نمایید'
            defaultValue={identifier}
            disabled={!!identifier}
          />
        </div>
        <div className='mb-6'>
          <label className='text-xl yekan-bold' htmlFor='confirmCode'>
            کد تایید
          </label>
          <input
            type='text'
            id='confirmCode'
            className='block w-full px-0.5 py-1.5 md:w-8/12 bg-transparent border-solid border-b border-white'
            placeholder='کد تایید خود را وارد نمایید'
          />
        </div>
        <button className='bg-primary w-full md:w-8/12 rounded-full py-1'>
          تایید
        </button>
        <p className='w-full md:w-8/12 text-center'>
          <button
            disabled={!resend}
            href='/auth/signin'
            className='disabled:text-gray-400'>
            ارسال مجدد کد{' '}
            {!resend && (
              <>
                ( <Counter startFrom={10} onEnd={endHandler} /> )
              </>
            )}
          </button>
        </p>
      </form>
    </RegisterCard>
  )
}

function ErrorMSG({ message }) {
  return message && <p className='text-red-400'>{message}</p>
}

export const getStaticProps = createStaticPropsWithNavData()
