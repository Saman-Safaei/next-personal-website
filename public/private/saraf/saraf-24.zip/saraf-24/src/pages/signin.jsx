import { Fragment, useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/router'

import DefaultLayout from '../layouts/DefaultLayout'
import Container from '../components/ui/Container'
import Counter from '../components/ui/Counter'
import LoginCard from '../components/ui/LoginCard'
import createStaticPropsWithNavData from "../api/helpers/navdata";

function SignIn({ navLinks }) {
  const router = useRouter()
  const [level, setLevel] = useState(0)
  const [identifier, setIdentifier] = useState('')

  useEffect(() => {
    if (router.query.identifier) {
      setLevel(1)
      setIdentifier(router.query.identifier)
    } else setLevel(0)
  }, [router.query.identifier])

  const signUpSubmitHandler = identifyName => {
    router.push('?identifier=' + identifyName)
  }

  return (
    <Container>
      {level === 0 && <SignUpForm onSubmit={signUpSubmitHandler} />}
      {level === 1 && <ConfirmEmailOrPhone identifier={identifier} />}
    </Container>
  )
}

SignIn.getLayout = (page, props) => (
  <DefaultLayout navbar footer title='ورود به حساب کاربری' navLinks={props.navLinks}>
    {page}
  </DefaultLayout>
)

export default SignIn

function SignUpForm({ onSubmit }) {
  const [errors, setErrors] = useState({
    identifierErr: '',
    passwordErr: '',
  })

  const resetErrors = () => {
    setErrors({ identifierErr: '', passwordErr: '' })
  }

  const formSubmitHandler = ev => {
    ev.preventDefault()
    const identifier = ev.target.identifier.value
    const password = ev.target.password.value

    resetErrors()

    if (!identifier.trim())
      return setErrors(prevErrors => ({
        ...prevErrors,
        identifierErr: 'نام کاربری یا شماره همراه را وارد کنید',
      }))

    if (!password.trim() && password.trim().length < 8)
      return setErrors(prevErrors => ({
        ...prevErrors,
        passwordErr: 'رمز عبور باید بیشتر از 8 کاراکتر باشد',
      }))

    onSubmit(identifier)
  }

  return (
    <LoginCard>
      <form
        onSubmit={formSubmitHandler}
        className='flex flex-col items-stretch gap-4'>
        <div>
          <label className='text-xl yekan-bold' htmlFor='identifier'>
            ایمیل یا شماره همراه
          </label>
          <input
            type='text'
            id='identifier'
            className='block w-full px-0.5 py-1.5 md:w-8/12 bg-transparent border-solid border-b border-white'
            placeholder='ایمیل یا شماره همراه خود را وارد نمایید'
          />
          <ErrorMSG message={errors.identifierErr} />
        </div>
        <div className='mb-8'>
          <label className='text-xl yekan-bold' htmlFor='password'>
            رمز عبور
          </label>
          <input
            type='text'
            id='password'
            className='block w-full px-0.5 py-1.5 md:w-8/12 bg-transparent border-solid border-b border-white'
            placeholder='رمز عبور خود را وارد نمایید'
          />
          <ErrorMSG message={errors.passwordErr} />
        </div>
        <button className='bg-primary w-full md:w-8/12 rounded-full py-1'>
          تایید
        </button>
        <div className='flex flex-row justify-center w-full md:w-8/12 gap-4'>
          <Link href='/forget_password'>فراموشی رمز عبور</Link>
          <span>|</span>
          <Link href='/signup'>ثبت نام در صراف 24</Link>
        </div>
      </form>
    </LoginCard>
  )
}

function ConfirmEmailOrPhone({ identifier }) {
  const [resend, setResend] = useState(false)

  const endHandler = () => {
    setResend(true)
  }

  return (
    <LoginCard>
      <form className='flex flex-col items-stretch gap-4'>
        <div>
          <label className='text-xl yekan-bold' htmlFor='identifier'>
            ایمیل یا شماره همراه
          </label>
          <input
            type='text'
            id='identifier'
            className='block w-full md:w-8/12 px-0.5 py-1.5 bg-transparent border-solid border-b border-white'
            placeholder='ایمیل یا شماره همراه خود را وارد نمایید'
            defaultValue={identifier}
            disabled={!!identifier}
          />
        </div>
        <div className='mb-6'>
          <label className='text-xl yekan-bold' htmlFor='confirmCode'>
            کد تایید
          </label>
          <input
            type='text'
            id='confirmCode'
            className='block w-full px-0.5 py-1.5 md:w-8/12 bg-transparent border-solid border-b border-white'
            placeholder='کد تایید خود را وارد نمایید'
          />
        </div>
        <button className='bg-primary w-full md:w-8/12 rounded-full py-1'>
          تایید
        </button>
        <p className='w-full md:w-8/12 text-center'>
          <button
            disabled={!resend}
            href='/auth/signin'
            className='block w-full disabled:text-gray-400'>
            ارسال مجدد کد{' '}
            {!resend && (
              <Fragment>
                ( <Counter startFrom={10} onEnd={endHandler} /> )
              </Fragment>
            )}
          </button>
          <button className='block w-full'>ارسال به شماره همراه</button>
        </p>
      </form>
    </LoginCard>
  )
}

function ErrorMSG({ message }) {
  return message && <p className='text-red-400'>{message}</p>
}


export const getStaticProps = createStaticPropsWithNavData()