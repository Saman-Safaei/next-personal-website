import { useState } from 'react'
import uiSlice from './uiSlice'

function UIProvider({ children }) {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)

  const toggleDrawerHandler = () => {
    setIsDrawerOpen(prevBoolean => !prevBoolean)
  }

  const sliceValue = {
    isDrawerOpen: isDrawerOpen,
    toggleDrawer: toggleDrawerHandler,
  }

  return <uiSlice.Provider value={sliceValue}>{children}</uiSlice.Provider>
}

export default UIProvider
