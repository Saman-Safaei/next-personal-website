import { createContext } from 'react'

export default createContext({
  isDrawerOpen: false,
  toggleDrawer: () => {},
})
