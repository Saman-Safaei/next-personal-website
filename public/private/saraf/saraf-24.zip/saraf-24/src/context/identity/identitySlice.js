import { createContext } from 'react'

export const defaultValues = {
  // values
  mobileNum: '',
  mobileConfirmed: false,
  name: '',
  lastName: '',
  meliCode: '',
  birthDate: '',
  gender: 0, // 0 for male - 1 for female
  meliCardImageUploaded: false,
  // actions
  setName: name => {},
  setLastName: lastName => {},
  setMeliCode: meliCode => {},
  setBirthDate: birthDate => {},
  setGender: gender => {},
  setCardImageUploaded: uploaded => {},
  setMobileNumber: number => {},
  setMobileConfirmed: confirmed => {},
}

export default createContext(defaultValues)
