import { useReducer } from 'react'
import identitySlice, { defaultValues } from './identitySlice'

function identityReducer(state, action) {
  if (action.type === 'UPDATE_MOBILE_NUM') {
    return { ...state, mobileNum: action.payload }
  }
  if (action.type === 'UPDATE_MOBILE_CONFIRMED') {
    return { ...state, mobileConfirmed: action.payload }
  }
  if (action.type === 'UPDATE_NAME') {
    return { ...state, name: action.payload }
  }
  if (action.type === 'UPDATE_LASTNAME') {
    return { ...state, lastName: action.payload }
  }

  return state
}

export default function IdentityProvider({ children }) {
  const [state, dispatch] = useReducer(identityReducer, defaultValues)

  const setMobileNumberHandler = number => {
    dispatch({ type: 'UPDATE_MOBILE_NUM', payload: number })
  }
  const setMobileConfirmedHandler = confirmed => {
    dispatch({ type: 'UPDATE_MOBILE_CONFIRMED', payload: confirmed })
  }

  const ctxValue = {
    ...state,
    setMobileNumber: setMobileNumberHandler,
    setMobileConfirmed: setMobileConfirmedHandler,
  }

  return (
    <identitySlice.Provider value={ctxValue}>{children}</identitySlice.Provider>
  )
}
