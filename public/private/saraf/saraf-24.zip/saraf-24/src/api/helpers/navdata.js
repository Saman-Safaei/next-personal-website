export default function createStaticPropsWithNavData(customFn = async () => {}, options = {}) {
  options.validateTime = 600

  return async function () {
    const navLinksResponse = await (await fetch('http://localhost:3000/api/navLinks')).json()

    let returningData = {};
    const runCustom = customFn()

    if (typeof runCustom.then === 'function') {
      returningData = await runCustom;
    } else {
      returningData = runCustom;
    }

    return {
      props: { navLinks: navLinksResponse.links, ...returningData },
      ...(options.revalidate && { revalidate: options.validateTime }),
    }
  }
}
