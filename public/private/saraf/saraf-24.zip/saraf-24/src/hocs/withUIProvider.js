import UIProvider from '../context/ui/UIProvider'

export default function withUIProvider(Component) {
  function Wrapper(props) {
    return (
      <UIProvider>
        <Component {...props} />
      </UIProvider>
    )
  }

  return Wrapper
}
