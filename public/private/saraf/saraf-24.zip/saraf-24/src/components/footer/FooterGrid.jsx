function FooterGrid({ children }) {
  return (
    <div className='grid grid-flow-dense grid-cols-1 special:grid-cols-4 justify-items-center gap-8'>
      {children}
    </div>
  )
}

export default FooterGrid
