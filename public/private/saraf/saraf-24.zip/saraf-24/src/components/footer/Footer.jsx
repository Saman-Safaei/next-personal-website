import FooterGrid from './FooterGrid'
import footerLinks from '../../assets/data/footerLinks.json'
import FooterGridItem from './FooterGridItem'

function Footer() {
  return (
    <footer
      dir='rtl'
      className='bg-gradient-to-br bg-[length:200%_200%] bg-center from-primary via-primary-dark to-custom-brown p-6 text-white text-lg'>
      <div className='max-w-normal mx-auto'>
        <FooterGrid>
          <div className='w-full flex flex-col items-stretch gap-2'>
            <div className='flex flex-row justify-start items-center gap-4 mb-4 h-16'>
              <img
                className='h-full object-contain'
                src='/images/logo.png'
                alt='logo'
              />
              <span className='text-3xl'>صراف 24</span>
            </div>
            <p>
              آدرس : جنت آباد شمالی، بین بهارستان 12 و چهارراه گلستان پلاک 313
              طبقه 3
            </p>
            <p>تلفن : 02191098564</p>
            <p>
              ایمیل : <span className='fenton'>info@saraf24.com</span>
            </p>
          </div>
          <FooterGridItem title='صراف 24' links={footerLinks.main} />
          <FooterGridItem
            title='اطلاعات و آموزش'
            links={footerLinks.education}
          />
          <FooterGridItem title='خدمات ویژه' links={footerLinks.special} />
        </FooterGrid>
        <hr className='mt-10 mb-6' />
        <p className='text-center'>تمامی حقوق این سامانه متعلق به صراف 24 می باشد.</p>
      </div>
    </footer>
  )
}

export default Footer
