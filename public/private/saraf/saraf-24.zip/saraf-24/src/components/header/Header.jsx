import Navbar from '../navbar/Navbar'
import Button from '../ui/Button'
import Input from '../ui/Input'

function Header({links}) {
  return (
    <header
      dir='rtl'
      className='flex flex-col items-stretch gap-28 text-white bg-black bg-[url("/images/headerbg.jpg")] bg-no-repeat bg-cover bg-right px-6 pt-8 pb-32'>
      <Navbar links={links} />
      <div className='w-full flex flex-row justify-start max-w-normal mx-auto px-4'>
        <div className='max-w-md'>
          <h2 className='yekan-bold text-4xl md:text-5xl mb-3'>
            انجام معاملات و ثبت سفارش در بازار حرفه ای صراف 24
          </h2>
          <p className='text-lg mb-8'>
            با سامانه صراف 24 میتوانید با استفاده از نمودار های قیمتی بصورت حرفه
            ای ثبت سفارش نمایید و خرید فروش خود را انجام دهید.
          </p>
          <div>
            <form className='flex flex-row justify-start gap-2 items-stretch'>
              <Input
                dir="auto"
                className='grow rounded-full py-1.5 px-3.5 text-black placeholder:text-right'
                placeholder='ایمیل خود را وارد کنید'
              />
              <Button className='shrink-0' type='submit'>
                شروع کنید
              </Button>
            </form>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header
