import Link from 'next/link'

function NavLink({ title, url }) {
  return (
    <li>
      <Link href={url} shallow className='text-white hover:text-primary-light transition-colors duration-300'>
        {title}
      </Link>
    </li>
  )
}

export default NavLink
