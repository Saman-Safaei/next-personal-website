import NavLink from './NavLink'
import uiSlice from '../../context/ui/uiSlice'
import { useContext } from 'react'
import Link from 'next/link'

function Navbar({ links, theme = 'dark' }) {
  const uiCtx = useContext(uiSlice)
  const colorClasses =
    theme === 'dark'
      ? 'from-white/40 to-white/5 text-gray-100'
      : 'from-black/80 to-black/20 text-gray-100'

  return (
    <div
      dir='ltr'
      className={`flex flex-row justify-between w-full max-w-normal h-14 px-4 py-2.5 mx-auto bg-gradient-to-br ${colorClasses} rounded-full`}>
      <div className='h-full shrink-0 flex flex-row items-center gap-1'>
        <img className='h-full' src='/images/logo.png' alt='logo' />
        <span className='fenton'>Saraf 24</span>
      </div>
      {/* for desktop */}
      <nav className='hidden lg:block h-full shrink-0'>
        <ul
          dir='rtl'
          className='h-full flex flex-row items-center text-lg gap-8'>
          {links.map(navLink => (
            <NavLink
              key={navLink.url}
              title={navLink.title}
              url={navLink.url}
            />
          ))}
        </ul>
      </nav>
      <div className='hidden lg:block h-full shrink-0'>
        <Link
          href='/signin'
          className='block h-full bg-white text-primary yekan-bold px-4 py-1.5 rounded-full'>
          ورود / ثبت نام
        </Link>
      </div>
      {/* for mobile */}
      <div className='lg:hidden h-full flex items-center justify-center'>
        <button className='w-7 h-7' onClick={uiCtx.toggleDrawer}>
          <svg
            xmlns='http://www.w3.org/2000/svg'
            fill='none'
            viewBox='0 0 24 24'
            strokeWidth={1.5}
            stroke='currentColor'
            className='w-full h-full'>
            <path
              strokeLinecap='round'
              strokeLinejoin='round'
              d='M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5'
            />
          </svg>
        </button>
      </div>
    </div>
  )
}

export default Navbar
