import { useEffect, useRef, useState, forwardRef, useImperativeHandle, useCallback } from 'react'

export default forwardRef(function SelectCoin(
  { items = [], onChange = value => {}, className = '', disabled = false },
  ref
) {
  const defaultState = {
    img: '/images/coins/adaicon.png',
    title: 'انتخاب کنید',
    value: null,
    zarib: 0,
  }
  const [selected, setSelected] = useState(defaultState)
  const [showCoins, setShowCoins] = useState(false)
  const dropDownRef = useRef()

  const clickHandler = () => {
    if (!disabled) setShowCoins(prevShow => !prevShow)
  }
  const selectHandler = value => {
    const item = items.find(item => item.value === value)
    if (item) setSelected(item)
    setShowCoins(false)
  }
  const clickOutsideHandler = useCallback(ev => {
    const xPos = ev.x
    const yPos = ev.y
    const clickedElement = document.elementFromPoint(xPos, yPos)
    if (!clickedElement === dropDownRef.current || !dropDownRef.current.contains(clickedElement)) {
      setShowCoins(false)
    }
  }, [])

  useEffect(() => {
    onChange(selected.value, selected.title, selected.zarib)
  }, [selected])

  useEffect(() => {
    document.addEventListener('click', clickOutsideHandler, { passive: true })
    return () => {
      document.removeEventListener('click', clickOutsideHandler)
    }
  }, [])

  useImperativeHandle(
    ref,
    () => ({
      setCoin: selectHandler,
      reset: () => setSelected(defaultState),
      coin: selected.value,
    }),
    [selected.value]
  )

  return (
    <div dir='rtl' className={`bg-white rounded-full text-black px-3 relative ${className}`} ref={dropDownRef}>
      <div
        className='flex flex-row justify-between items-center select-none cursor-pointer py-3 gap-3'
        onClick={clickHandler}>
        <span className='flex flex-row items-center gap-2'>
          <img src={selected.img} alt='icon' className='w-6 h-6 rounded-full' />
          <span>{selected.title}</span>
        </span>
        <span>
          <svg
            xmlns='http://www.w3.org/2000/svg'
            fill='none'
            viewBox='0 0 24 24'
            strokeWidth={1.5}
            stroke='currentColor'
            className='w-4 h-4'>
            <path strokeLinecap='round' strokeLinejoin='round' d='M19.5 8.25l-7.5 7.5-7.5-7.5' />
          </svg>
        </span>
      </div>
      {showCoins && (
        <div className='flex flex-col justify-start absolute top-[115%] right-0 w-max min-w-full bg-white p-4 rounded-md z-20'>
          {items
            .filter(item => item.value !== 'IRT')
            .map(item => (
              <button
                className='text-start py-1 whitespace-nowrap'
                key={item.value}
                onClick={() => selectHandler(item.value)}>
                <span className='flex flex-row items-center gap-2'>
                  <img src={item.img} alt='icon' className='w-6 h-6 rounded-full' />
                  <span>{item.title}</span>
                </span>
              </button>
            ))}
        </div>
      )}
    </div>
  )
})
