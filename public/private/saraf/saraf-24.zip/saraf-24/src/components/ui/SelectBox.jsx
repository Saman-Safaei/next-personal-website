import { useEffect, useRef, useState } from 'react'

export default function SelectBox({
  items = [],
  onChange = () => {},
  className = '',
  placeholder = 'انتخاب کنید'
}) {
  const [selected, setSelected] = useState(
    items.length > 0 ? items[0] : { title: placeholder, value: null }
  )
  const [showMenu, setShowMenu] = useState(false)
  const dropDownRef = useRef()

  const clickHandler = () => {
    setShowMenu(prevShow => !prevShow)
  }
  const selectHandler = value => {
    setSelected(items.find(item => item.value === value))
    setShowMenu(false)
  }
  const clickOutsideHandler = ev => {
    const xPos = ev.x
    const yPos = ev.y
    const clickedElement = document.elementFromPoint(xPos, yPos)
    if (
      !clickedElement === dropDownRef.current ||
      !dropDownRef.current.contains(clickedElement)
    ) {
      setShowMenu(false)
    }
  }

  useEffect(() => {
    onChange(selected.value)
  }, [selected])

  useEffect(() => {
    document.addEventListener('click', clickOutsideHandler, { passive: true })
    return () => {
      document.removeEventListener('click', clickOutsideHandler)
    }
  }, [])

  return (
    <div className={`relative ${className}`} ref={dropDownRef}>
      <div
        className='flex flex-row justify-between items-center select-none cursor-pointer py-3 gap-3'
        onClick={clickHandler}>
        <span>{selected.title}</span>
        <span>
          <svg
            xmlns='http://www.w3.org/2000/svg'
            fill='none'
            viewBox='0 0 24 24'
            strokeWidth={1.5}
            stroke='currentColor'
            className='w-4 h-4'>
            <path
              strokeLinecap='round'
              strokeLinejoin='round'
              d='M19.5 8.25l-7.5 7.5-7.5-7.5'
            />
          </svg>
        </span>
      </div>
      {showMenu && (
        <div className='flex flex-col justify-start absolute top-full right-0 min-w-full bg-[#141414] p-4 rounded-md z-20 text-white'>
          {items.map(item => (
            <button
              className='text-start py-1 whitespace-nowrap'
              key={item.value}
              onClick={() => selectHandler(item.value)}>
              {item.title}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
