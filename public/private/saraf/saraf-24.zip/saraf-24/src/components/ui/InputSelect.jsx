import { useEffect, useRef, useState } from 'react'

export default function InputSelect({
  items = [],
  onChange = () => {},
  className = '',
  defaultValue,
}) {
  const [search, setSearch] = useState('')
  const defaultSelected =
    defaultValue && items.length > 0
      ? items.find(item => item.value === defaultValue)
      : items.length > 0
      ? items[0]
      : { title: 'انتخاب کنید', value: null }
  const dropDownRef = useRef()

  const [selected, setSelected] = useState(defaultSelected)
  const [showMenu, setShowMenu] = useState(false)
  const filteredItems = items.filter(item =>
    search ? item.title.includes(search) : true
  )

  const inputRef = useRef()

  const clickHandler = () => {
    setShowMenu(prevShow => !prevShow)
  }
  const selectHandler = value => {
    const selectedItem = items.find(item => item.value === value)
    setSearch('')
    setSelected(selectedItem)
    setShowMenu(false)
    inputRef.current.value = selectedItem.title
  }
  const typingHandler = ev => {
    setSearch(inputRef.current.value)
  }
  const clickOutsideHandler = ev => {
    const xPos = ev.x
    const yPos = ev.y
    const clickedElement = document.elementFromPoint(xPos, yPos)
    if (
      !clickedElement === dropDownRef.current ||
      !dropDownRef.current.contains(clickedElement)
    ) {
      setShowMenu(false)
    }
  }

  useEffect(() => {
    onChange(selected.value)
  }, [selected])

  useEffect(() => {
    document.addEventListener('click', clickOutsideHandler, { passive: true })
    return () => {
      document.removeEventListener('click', clickOutsideHandler)
    }
  }, [])

  return (
    <div className={`relative ${className}`} ref={dropDownRef}>
      <div
        className='flex flex-row justify-between items-center select-none cursor-pointer py-3 gap-3'
        onClick={clickHandler}>
        <input
          ref={inputRef}
          type='text'
          defaultValue={selected.title}
          onInput={typingHandler}
        />
        <span>
          <svg
            xmlns='http://www.w3.org/2000/svg'
            fill='none'
            viewBox='0 0 24 24'
            strokeWidth={1.5}
            stroke='currentColor'
            className='w-4 h-4'>
            <path
              strokeLinecap='round'
              strokeLinejoin='round'
              d='M19.5 8.25l-7.5 7.5-7.5-7.5'
            />
          </svg>
        </span>
      </div>
      {showMenu && (
        <div className='flex flex-col justify-start absolute top-full right-0 min-w-full bg-[#141414] p-4 rounded-md z-20'>
          {filteredItems.map(item => (
            <button
              className='text-start py-1 whitespace-nowrap'
              key={item.value}
              onClick={() => selectHandler(item.value)}>
              {item.title}
            </button>
          ))}
          {filteredItems.length === 0 && (
            <div className='text-center'>ارز پیدا نشد</div>
          )}
        </div>
      )}
    </div>
  )
}
