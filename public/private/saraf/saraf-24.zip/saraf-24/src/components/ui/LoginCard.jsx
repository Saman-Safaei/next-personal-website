import styles from '../../styles/Auth.module.css'

export default function LoginCard({ children }) {
  return (
    <div className='md:min-h-[38rem] rounded-3xl md:rounded-[2rem] flex flex-row items-stretch overflow-hidden'>
      <div
        className={`hidden md:flex flex-col items-center w-5/12 shrink-0' ${styles['logo-bg__dark']} p-6 gap-4`}>
        <img src='/images/logo.png' alt='logo' className='shrink-0' />
        <h3 className='shrink-0 text-3xl yekan-bold text-center'>
          جست و جو در دنیای رمز ارز ها با صراف 24
        </h3>
        <div className='grow w-full grid grid-cols-1 lg:grid-cols-2 grid-flow-dense content-evenly justify-items-stretch gap-y-4 gap-x-6'>
          <CoinData
            imgSrc='/images/coins/bitcoinicon.png'
            name='BTC'
            price={16950.2}
            percentage={-0.7}
          />
          <CoinData
            imgSrc='/images/coins/adaicon.png'
            name='ADA'
            price={0.3137}
            percentage={-0.5}
          />
          <CoinData
            imgSrc='/images/coins/etheriumicon.png'
            name='ETH'
            price={1274.83}
            percentage={-0.32}
          />
          <CoinData
            imgSrc='/images/coins/tetericon.png'
            name='USDT'
            price={1}
            percentage={0.003}
          />
        </div>
        <div className='shrink-0 w-full flex flex-row items-center justify-end gap-3'>
          <div dir='rtl'>
            <h4>برای دانلود اپلیکیشن موبایل صراف 24 اسکن کنید.</h4>
            <p className='text-xs'>معامله کردن را شروع کنید.</p>
          </div>
          <div className='w-14 h-14'>
            <img
              className='h-full w-full object-contain'
              src='/images/qrcode.png'
              alt='qrcode'
            />
          </div>
        </div>
      </div>
      <div dir='rtl' className='grow py-6 px-8 md:px-14 relative'>
        <div className='absolute inset-0 bg-[url(/images/bgcharts.png)] bg-center bg-no-repeat bg-contain -z-20' />
        <div className='absolute inset-0 bg-gradient-to-br from-white/20 to-transparent -z-10 backdrop-blur-md' />
        <div className='w-full h-full flex flex-col items-stretch justify-center z-0'>
          <div className='flex flex-row gap-3'>
            <img
              src='/images/logo_signin.png'
              className='w-8 h-8 object-contain'
            />
            <h3 className='text-3xl yekan-bold'>ورود به حساب صراف 24</h3>
          </div>
          <h4 className='text-lg mb-6'>لطفا با حساب کاربری خود وارد شوید</h4>
          {children}
        </div>
      </div>
    </div>
  )
}

function CoinData({ imgSrc, price = 0, name = '', percentage = 0 }) {
  const textColor = percentage > 0 ? 'text-green-400' : 'text-red-400'

  return (
    <div className={`relative flex flex-row items-center gap-4 pb-3 border-solid border-b-2 border-b-white ${styles.circle}`}>
      <div className='w-12 h-12 shrink-0'>
        <img
          src={imgSrc}
          alt='coin_logo'
          className='w-full h-full object-contain'
        />
      </div>
      <div className={`font-sans ${textColor}`}>
        <h4 className='text-lg text-gray-100'>{name}</h4>
        <div className='flex flex-row justify-between gap-4 text-sm'>
          <span>{price.toLocaleString()}$</span>
          <span>{percentage}</span>
        </div>
      </div>
    </div>
  )
}
