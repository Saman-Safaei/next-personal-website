function Input({ children , className = '', ...props }) {
  return <input className={`${className}`} {...props} />
}

export default Input
