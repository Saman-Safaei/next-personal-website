import { useEffect, useState } from 'react'

function Counter({ startFrom = 60, onEnd }) {
  const [currentCount, setCurrentCount] = useState(startFrom)

  useEffect(() => {
    if (currentCount > 0)
      setTimeout(() => setCurrentCount(prevCount => prevCount - 1), 1000)
    if (currentCount === 0) onEnd()
  }, [currentCount])
  return <span>{currentCount}</span>
}

export default Counter
