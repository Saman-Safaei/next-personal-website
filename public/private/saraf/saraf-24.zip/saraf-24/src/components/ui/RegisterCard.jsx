import styles from '../../styles/Auth.module.css'

function RegisterCard({ children }) {
  return (
    <div className='md:min-h-[38rem] rounded-3xl md:rounded-[2rem] flex flex-row items-stretch overflow-hidden'>
      <div
        className={`hidden md:flex flex-col items-center w-5/12 shrink-0' ${styles['logo-bg']} p-6 gap-4`}>
        <img src='/images/logo.png' alt='logo' />
        <h3 className='text-3xl yekan-bold text-center'>
          خرید و فروش امن
          <br />
          در دنیای رمز ارز ها
        </h3>
        <div className='w-full mt-auto flex flex-row items-center justify-end gap-3'>
          <div dir='rtl'>
            <h4>برای دانلود اپلیکیشن موبایل صراف 24 اسکن کنید.</h4>
            <p className='text-xs'>معامله کردن را شروع کنید.</p>
          </div>
          <div className='w-14 h-14'>
            <img className='h-full w-full object-contain' src="/images/qrcode.png" alt="qrcode" />
          </div>
        </div>
      </div>
      <div dir='rtl' className='grow py-6 px-8 md:px-14 relative'>
        <div className='absolute inset-0 bg-[url(/images/bgcharts.png)] bg-center bg-no-repeat bg-contain -z-20' />
        <div className='absolute inset-0 bg-gradient-to-br from-white/20 to-transparent -z-10 backdrop-blur-md' />
        <div className='w-full h-full flex flex-col items-stretch justify-center z-0'>
          <div className='flex flex-row gap-3'>
            <img
              src='/images/logo_signin.png'
              className='w-8 h-8 object-contain'
            />
            <h3 className='text-3xl yekan-bold'>ثبت نام در سامانه صراف 24</h3>
          </div>
          <h4 className='text-lg mb-6'>وارد دنیای زیبای رمز ارز ها شوید</h4>
          {children}
        </div>
      </div>
    </div>
  )
}

export default RegisterCard
