function Button({ className = '', children, ...props }) {
  return (
    <button className={`text-white bg-primary hover:bg-primary-light active:bg-primary-dark px-3.5 py-1.5 rounded-full shadow ${className} transition-all duration-300`} {...props}>
      {children}
    </button>
  )
}

export default Button
