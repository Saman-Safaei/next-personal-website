function Container({ children, className = '', ...props }) {
  const paddingClass =
    className.includes('px') ||
    className.includes('py') ||
    className.includes('p-')
      ? ''
      : 'py-6 px-6'

  return (
    <div className={`${paddingClass} ${className}`} {...props}>
      <div className='max-w-normal mx-auto'>{children}</div>
    </div>
  )
}

export default Container
