import Link from 'next/link'
import { Fragment, useContext } from 'react'
import { CSSTransition } from 'react-transition-group'
import uiSlice from '../../context/ui/uiSlice'
import DrawerLink from './DrawerLink'

function Drawer({ links }) {
  const uiCtx = useContext(uiSlice)
  const translateClasses = uiCtx.isDrawerOpen ? 'translate-x-0' : 'translate-x-full'

  return (
    <Fragment>
      <CSSTransition in={uiCtx.isDrawerOpen} timeout={500} classNames='fade' unmountOnExit>
        <div onClick={uiCtx.toggleDrawer} className='fixed inset-0 bg-black/40 z-30' />
      </CSSTransition>
      <aside
        className={`flex flex-col items-stretch justify-start gap-6 fixed top-0 bottom-0 right-0 w-full max-w-xs bg-gray-800 ${translateClasses} transition-all duration-500 z-40`}>
        <div className='h-20 flex flex-row items-center justify-between px-4 py-5 text-white shrink-0'>
          <button onClick={uiCtx.toggleDrawer} className='h-7 w-7'>
            <svg
              xmlns='http://www.w3.org/2000/svg'
              fill='none'
              viewBox='0 0 24 24'
              strokeWidth={1.5}
              stroke='currentColor'
              className='w-full h-full'>
              <path strokeLinecap='round' strokeLinejoin='round' d='M6 18L18 6M6 6l12 12' />
            </svg>
          </button>
          <div className='h-full py-1 flex flex-row-reverse items-center gap-4'>
            <img className='h-full' src='/images/logo.png' alt='logo' />
            <span className='fenton text-lg'>Saraf 24</span>
          </div>
        </div>
        <div dir='rtl' className='flex flex-col gap-2 items-stretch grow overflow-y-auto overflow-x-hidden px-4'>
          <Link
            href='/signup'
            className='w-full bg-primary-dark hover:bg-primary py-4 text-center text-white rounded-full mb-4 transition-all 300ms'>
            ورود / ثبت نام
          </Link>
          {links.map(link => (
            <DrawerLink key={link.title} to={link.url} onClick={uiCtx.toggleDrawer}>
              {link.title}
            </DrawerLink>
          ))}
        </div>
      </aside>
    </Fragment>
  )
}

export default Drawer
