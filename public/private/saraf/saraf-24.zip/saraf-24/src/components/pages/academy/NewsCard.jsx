import React from 'react'

export default function NewsCard({ title, image, date, link }) {
  return (
    <div
      className={`group flex flex-col md:odd:flex-col md:even:flex-col-reverse items-stretch bg-stone-800 rounded-3xl overflow-hidden text-gray-100 shadow-black/40 shadow-md`}
      dir='rtl'>
      <div className='shrink-0 h-64 w-full'>
        <img className='rounded-b-3xl md:group-odd:rounded-b-3xl md:group-even:rounded-t-3xl w-full h-full object-cover' src={image} alt={title} />
      </div>
      <div className='flex flex-col items-stretch grow gap-8 md:gap-2 py-8 md:py-4 p-4'>
        <a href={link} className='text-2xl'>
          {title}
        </a>
        <p className='mt-auto text-end text-xs text-gray-400'>{date}</p>
      </div>
    </div>
  )
}
