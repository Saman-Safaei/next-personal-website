import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { CSSTransition, SwitchTransition } from 'react-transition-group'

export default function HeaderSlider({ slides = [] }) {
  const [pages, setState] = useState(0)
  const [buttonEnabled, setButtonsEnabled] = useState(true)
  const imgRef = useRef()

  const slideDots = slides.map((value, index) => (
    <span
      key={index}
      className={`block w-2 h-2 rounded-full ${index === pages ? 'bg-white' : 'bg-gray-400'} transition duration-300`}
    />
  ))

  const nextHandler = () => {
    setButtonsEnabled(false)
    setTimeout(() => setButtonsEnabled(true), 1000)
    setState(prevState => {
      if (prevState + 1 >= slides.length) return 0
      else return prevState + 1
    })
  }
  const prevHandler = () => {
    setButtonsEnabled(false)
    setTimeout(() => setButtonsEnabled(true), 1000)
    setState(prevState => {
      if (prevState - 1 < 0) return slides.length - 1
      else return prevState - 1
    })
  }

  useEffect(() => {
    let interval = setTimeout(() => {
      nextHandler()
    }, 5000)

    return () => {
      clearTimeout(interval)
    }
  }, [pages])

  return (
    <div className='z-0 relative aspect-[14/9] lg:aspect-[18/9] rounded-3xl overflow-hidden mb-4' dir='rtl'>
      <SwitchTransition mode='out-in'>
        <CSSTransition
          key={pages}
          classNames='slide'
          nodeRef={imgRef}
          timeout={200}>
          <img
            ref={imgRef}
            className={'absolute top-0 left-0 h-full w-full object-cover transition duration-300'}
            src={slides[pages]?.img ?? '/images/tshirtman.png'}
            alt='slider'
          />
        </CSSTransition>
      </SwitchTransition>
      <div className='z-[1] absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/80 to-transparent'>
        <Link
          className='p-1 px-4 text-center lg:text-start lg:p-4 text-white text-xl sm:text-2xl md:text-3xl lg:text-4xl'
          href={slides[pages]?.url ?? '#'}>
          {slides[pages]?.title}
        </Link>
        <div className='flex justify-between items-center p-4 pt-0 lg:pt-4'>
          <button disabled={!buttonEnabled} onClick={prevHandler} className='text-white'>
            <svg
              xmlns='http://www.w3.org/2000/svg'
              fill='none'
              viewBox='0 0 24 24'
              strokeWidth='1.5'
              stroke='currentColor'
              className='w-8 h-8'>
              <path strokeLinecap='round' strokeLinejoin='round' d='M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3' />
            </svg>
          </button>
          <div className='flex flex-row gap-0.5'>{slideDots}</div>
          <button disabled={!buttonEnabled} onClick={nextHandler} className='text-white'>
            <svg
              xmlns='http://www.w3.org/2000/svg'
              fill='none'
              viewBox='0 0 24 24'
              strokeWidth='1.5'
              stroke='currentColor'
              className='w-8 h-8'>
              <path strokeLinecap='round' strokeLinejoin='round' d='M6.75 15.75L3 12m0 0l3.75-3.75M3 12h18' />
            </svg>
          </button>
        </div>
      </div>
    </div>
  )
}
