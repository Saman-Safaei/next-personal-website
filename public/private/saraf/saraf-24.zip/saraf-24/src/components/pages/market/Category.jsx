import React from 'react'

function Category({ children }) {
  return <button className='block px-2 py-1 hover:bg-white/10 rounded-md transition duration-300'>{children}</button>
}

export default Category