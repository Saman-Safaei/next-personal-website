function GreenDot(props) {
  return (
    <span className='inline-block w-2 h-2 rounded-full bg-primary ml-1'/>
  );
}

export default GreenDot;