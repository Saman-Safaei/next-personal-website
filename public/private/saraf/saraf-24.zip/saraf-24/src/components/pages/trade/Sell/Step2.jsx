import Link from 'next/link'
import { Fragment } from 'react'

export default function Step2({ state }) {
  return (
    <div dir='rtl'>
      <h3 className='text-2xl font-bold text-center mb-2'>
        {!state.isTransitionSuccessful ? (
          <Fragment>عملیات فروش ناموفق بود</Fragment>
        ) : (
          <Fragment>فروش شما با موفقیت انجام شد.</Fragment>
        )}
      </h3>
      <p className='text-lg text-center mb-8'>
        {!state.isTransitionSuccessful ? (
          <Fragment>
            لطفا دوباره تلاش کنید یا با پشتیبانی صراف 24 تماس بگیرید.
          </Fragment>
        ) : (
          <Fragment>به زودی به کیف پولتان واریز می شود.</Fragment>
        )}
      </p>
      {state.isTransitionSuccessful && (
        <div className='bg-white/90 p-4 rounded-3xl text-black mb-8'>
          <p className='flex align-baseline justify-between'>
            <span>دریافتی شما:</span>
            <span>{state.receive} تومان</span>
          </p>
          <span className='block w-full h-[2px] bg-black my-2' />
          <p className='flex align-baseline justify-between'>
            <span>مبلغ:</span>
            <span>
              {state.pay} {state.payCoin.name}
            </span>
          </p>
        </div>
      )}
      {!state.isTransitionSuccessful && (
        <Fragment>
          <Link href='/contact-us' className='button block w-full mb-2'>
            تماس با پشتیبانی
          </Link>
        </Fragment>
      )}
      <Link href='/' className='button block w-full'>
        بازگشت به صفحه اصلی
      </Link>
    </div>
  )
}
