import React from 'react'

function AnalysisCard({ title, url = '#', image }) {
  return (
    <div className='relative bg-gray-400 rounded-3xl shadow-black/40 shadow min-h-[14rem] overflow-hidden z-0'>
      <img
        className='absolute top-0 right-0 w-full h-full object-cover z-[-1]'
        src={image}
        alt='bitcoin-creation'
      />
      <div
        className='text-white absolute inset-0 bg-gradient-to-t from-black/80 to-black/10 flex flex-col justify-end p-4 md:p-6'
        dir='rtl'>
        <a href={url}>
          <h4 className='text-3xl'>{title}</h4>
        </a>
      </div>
    </div>
  )
}

export default AnalysisCard