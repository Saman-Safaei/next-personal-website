import React from 'react';

function DownloadLink({icon, title, link}) {
  return (
    <li>
      <a href={link} download>
        <div className='w-fit flex flex-row items-center gap-3 py-1'>
          <img className='w-10 h-10 object-contain' src={icon} alt={title} />
          <span className='text-xl'>{title}</span>
        </div>
      </a>
    </li>
  );
}

export default DownloadLink;