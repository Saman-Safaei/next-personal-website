import React from 'react'
import { Splide, SplideSlide, SplideTrack } from '@splidejs/react-splide'

function NewPostsSlider(props) {
  return (
    <section className='py-4'>
      <Splide
        hasTrack={false}
        options={{
          perPage: 1,
          pagination: false,
          direction: 'rtl',
          mediaQuery: 'min',
          gap: '2rem',
          breakpoints: {
            500: {
              perPage: 2,
            },
            800: {
              perPage: 3,
            },
          },
        }}
        aria-label='My Favorite Images'
        dir='rtl'>
        <SplideTrack>
          <SplideSlide>
            <div className='h-full flex flex-col items-stretch bg-stone-800 text-gray-100 rounded-3xl overflow-hidden'>
              <div className='shrink-0 w-full h-52 border-solid border-b-4 border-b-primary'>
                <img className='w-full h-full object-cover' src='/images/bitcoin-creation.png' alt='no-alt' />
              </div>
              <div className='flex flex-col items-stretch gap-2 grow p-4'>
                <div className='mb-2'>
                  <h4 className='text-2xl'>سوشال فای چیست؟</h4>
                  <p className='text-lg text-gray-300'>همه چیز درباره سوشال فای که باید بدانید!</p>
                </div>
                <a className='mt-auto' href="#">
                  <button className='block mx-auto border-solid border-b-primary border-b-2'>در ادامه بخوانید</button>
                </a>
                <div className='flex flex-row justify-between items-center'>
                  <p className='text-gray-400 text-sm'>25 دی 1401</p>
                  <img className='h-6 w-6' src="/images/heart-like.svg" alt="like"/>
                </div>
              </div>
            </div>
          </SplideSlide>
          <SplideSlide>
            <div className='h-full flex flex-col items-stretch bg-stone-800 text-gray-100 rounded-3xl overflow-hidden'>
              <div className='shrink-0 w-full h-52 border-solid border-b-4 border-b-primary'>
                <img className='w-full h-full object-cover' src='/images/bitcoin-creation.png' alt='no-alt' />
              </div>
              <div className='flex flex-col items-stretch gap-2 grow p-4'>
                <div className='mb-2'>
                  <h4 className='text-2xl'>سوشال فای چیست؟</h4>
                  <p className='text-lg text-gray-300'>همه چیز درباره سوشال فای که باید بدانید!</p>
                </div>
                <a className='mt-auto' href="#">
                  <button className='block mx-auto border-solid border-b-primary border-b-2'>در ادامه بخوانید</button>
                </a>
                <div className='flex flex-row justify-between items-center'>
                  <p className='text-gray-400 text-sm'>25 دی 1401</p>
                  <img className='h-6 w-6' src="/images/heart-like.svg" alt="like"/>
                </div>
              </div>
            </div>
          </SplideSlide>
          <SplideSlide>
            <div className='h-full flex flex-col items-stretch bg-stone-800 text-gray-100 rounded-3xl overflow-hidden'>
              <div className='shrink-0 w-full h-52 border-solid border-b-4 border-b-primary'>
                <img className='w-full h-full object-cover' src='/images/bitcoin-creation.png' alt='no-alt' />
              </div>
              <div className='flex flex-col items-stretch gap-2 grow p-4'>
                <div className='mb-2'>
                  <h4 className='text-2xl'>سوشال فای چیست؟</h4>
                  <p className='text-lg text-gray-300'>همه چیز درباره سوشال فای که باید بدانید!</p>
                </div>
                <a className='mt-auto' href="#">
                  <button className='block mx-auto border-solid border-b-primary border-b-2'>در ادامه بخوانید</button>
                </a>
                <div className='flex flex-row justify-between items-center'>
                  <p className='text-gray-400 text-sm'>25 دی 1401</p>
                  <img className='h-6 w-6' src="/images/heart-like.svg" alt="like"/>
                </div>
              </div>
            </div>
          </SplideSlide>
          <SplideSlide>
            <div className='h-full flex flex-col items-stretch bg-stone-800 text-gray-100 rounded-3xl overflow-hidden'>
              <div className='shrink-0 w-full h-52 border-solid border-b-4 border-b-primary'>
                <img className='w-full h-full object-cover' src='/images/bitcoin-creation.png' alt='no-alt' />
              </div>
              <div className='flex flex-col items-stretch gap-2 grow p-4'>
                <div className='mb-2'>
                  <h4 className='text-2xl'>سوشال فای چیست؟</h4>
                  <p className='text-lg text-gray-300'>همه چیز درباره سوشال فای که باید بدانید!</p>
                </div>
                <a className='mt-auto' href="#">
                  <button className='block mx-auto border-solid border-b-primary border-b-2'>در ادامه بخوانید</button>
                </a>
                <div className='flex flex-row justify-between items-center'>
                  <p className='text-gray-400 text-sm'>25 دی 1401</p>
                  <img className='h-6 w-6' src="/images/heart-like.svg" alt="like"/>
                </div>
              </div>
            </div>
          </SplideSlide>
        </SplideTrack>
        <div className='splide__arrows flex flex-row justify-center gap-2 pt-2'>
          <button className='splide__arrow splide__arrow--prev'>
            <svg
              xmlns='http://www.w3.org/2000/svg'
              fill='none'
              viewBox='0 0 24 24'
              strokeWidth={1.5}
              stroke='currentColor'
              className='w-8 h-8 text-custom-brown'>
              <path strokeLinecap='round' strokeLinejoin='round' d='M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3' />
            </svg>
          </button>
          <button className='splide__arrow splide__arrow--next'>
            <svg
              xmlns='http://www.w3.org/2000/svg'
              fill='none'
              viewBox='0 0 24 24'
              strokeWidth={1.5}
              stroke='currentColor'
              className='w-8 h-8 text-custom-brown'>
              <path strokeLinecap='round' strokeLinejoin='round' d='M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18' />
            </svg>
          </button>
        </div>
      </Splide>
    </section>
  )
}

export default NewPostsSlider
