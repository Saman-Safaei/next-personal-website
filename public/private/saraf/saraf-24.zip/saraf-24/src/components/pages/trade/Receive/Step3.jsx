import Link from 'next/link'
import { Fragment } from 'react'

export default function Receive3({ state }) {
  return (
    <div dir='rtl'>
      <h3 className='text-3xl font-bold text-center'>
        {!state.isTransitionSuccessful ? (
          <Fragment>عملیات خرید ناموفق بود</Fragment>
        ) : (
          <Fragment>خرید شما با موفقیت انجام شد.</Fragment>
        )}
      </h3>
      <p className='text-center mb-10'>به زودی به کیف پولتان واریز می شود.</p>
      {state.isTransitionSuccessful && (
        <div className='bg-white p-4 rounded-3xl text-gray-700 mb-8'>
          <p className='flex items-baseline justify-between'>
            <span>دریافتی شما:</span>
            <span className='font-sans text-sm text-black'>
              {state.receive} {state.receiveCoin.value}
            </span>
          </p>
          <span className='block w-full h-[2px] bg-gray-400 my-2' />
          <p className='flex items-baseline justify-between'>
            <span>مبلغ:</span>
            <span className='font-sans text-sm text-black'>
              {state.pay} {state.pay.value}
            </span>
          </p>
        </div>
      )}
      {!state.isTransitionSuccessful && (
        <Fragment>
          <Link href='/contact-us' className='button block w-full mb-2'>
            تماس با پشتیبانی
          </Link>
        </Fragment>
      )}
      <Link className='button w-full block text-center' href='/'>
        بازگشت به صفحه اصلی
      </Link>
    </div>
  )
}