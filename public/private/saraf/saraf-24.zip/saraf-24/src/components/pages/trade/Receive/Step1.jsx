import { walletTypes } from '../../../../hooks/useTrade'
import SelectBox from '../../../ui/SelectBox'

export default function Receive1({ state, actions, nextStep }) {
  return (
    <div dir='rtl'>
      <h3 className='text-2xl font-bold text-center mb-2'>
        به کدام کیف پول واریز شود؟
      </h3>
      <p className='text-center text-sm mb-8 font-sans'>{state.receive} BTC</p>

      <div
        className={`select-none cursor-pointer flex flex-row bg-white py-4 px-6 rounded-full text-black mb-2 border-solid border-4 ${
          state.buyState.selectedWallet === walletTypes.SARAF_WALLET
            ? 'border-primary'
            : 'border-white'
        }`}
        onClick={() => actions.setWalletType(walletTypes.SARAF_WALLET)}>
        <div className='grow'>
          <h4 className='text-2xl font-bold'>کیف پول صراف 24</h4>
          <p className='text-sm'>واریز تا 30 دقیقه بدون کارمزد</p>
        </div>
        <img
          className='w-14 h-14'
          src='/images/walleticonsvg.svg'
          alt='wallet'
        />
      </div>
      <div
        className={`select-none cursor-pointer flex flex-row bg-white py-4 px-6 rounded-full text-black mb-8 border-solid border-4 ${
          state.buyState.selectedWallet === walletTypes.OTHER_WALLET
            ? 'border-primary'
            : 'border-white'
        }`}
        onClick={() => actions.setWalletType(walletTypes.OTHER_WALLET)}>
        <div className='grow'>
          <h4 className='text-2xl font-bold'>کیف پول دیگر</h4>
          <p className='text-sm'>واریز تا 12 ساعت + کارمزد انتقال</p>
        </div>
        <img
          className='w-14 h-14'
          src='/images/walleticonsvg.svg'
          alt='wallet'
        />
      </div>
      {state.buyState.selectedWallet === walletTypes.OTHER_WALLET && (
        <div className='mb-4'>
          <p>انتخاب شبکه</p>
          <SelectBox
            className='border-solid border-white border-b-[2px]'
            items={[
              { title: 'بیت کوین', value: '234242' },
              { title: 'تتر', value: '1234' },
              { title: 'کاردانو', value: '24324' },
            ]}
            onChange={value => {
              actions.setChannel(value)
            }}
          />
          <div className='flex flex-row items-center border-solid border-b-2 border-white'>
            <input
              onChange={actions.onWalletAddressChange}
              value={state.buyState.walletAddress}
              type='text'
              className='py-3 grow'
              placeholder='آدرس کیف پول'
            />
            <img width='w-8 h-8' src='/images/scansvg.svg' alt='scan' />
          </div>
          <p className='flex justify-between items-baseline py-2 text-sm text-gray-300'>
            <span>کارمزد:</span>
            <span>2 تتر</span>
          </p>
        </div>
      )}
      {state.buyState.selectedWallet === walletTypes.SARAF_WALLET && (
        <p className='text-sm text-center mb-2'>
          با انتخاب این گزینه خرید شما وارد کیف پول صراف 24 خواهد شد.
        </p>
      )}
      <button
        disabled={
          (state.buyState.selectedWallet === walletTypes.OTHER_WALLET &&
            !state.buyState.walletAddress) ||
          (state.buyState.selectedWallet === walletTypes.OTHER_WALLET &&
            !state.buyState.channel)
        }
        onClick={() => nextStep()}
        className='button w-full block'>
        ادامه
      </button>
    </div>
  )
}
