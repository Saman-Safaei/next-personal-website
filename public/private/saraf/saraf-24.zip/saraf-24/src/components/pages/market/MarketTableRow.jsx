import React, { useId, useMemo } from 'react'
import dynamic from 'next/dynamic'

function MarketTableRow({
  changes,
  changesChart = [0],
  name,
  icon,
  symbol = 'NONE',
  price = 1,
  unit = 'teter',
  unitPrice = 24,
}) {
  const Chart = dynamic(() => import('react-apexcharts'), { ssr: false })
  const changesColor = changes < 0 ? 'text-red-500' : 'text-green-500'

  const chartOptions = {
    chart: {
      toolbar: {
        show: false,
      },
      zoom: {
        enabled: false,
      },
      animations: {
        enabled: false,
      },
      id: useId(),
    },
    xaxis: {
      labels: {
        show: false,
      },
      tooltip: {
        enabled: false,
      },
    },
    yaxis: {
      labels: {
        show: false,
      },
    },
    grid: {
      show: false,
    },
    tooltip: {
      x: {
        show: false,
      },
      marker: {
        show: false,
      },
      y: {
        title: {
          formatter: () => `$`,
        },
      },
    },
  }

  const series = [
    {
      name: 'Prices',
      data: changesChart.map(num => (unit === 'toman' ? num * unitPrice : num)),
    },
  ]

  return (
    <tr>
      <td className='px-4 py-2 w-1/3 text-lg'>
        <div className='flex flex-row items-center gap-2'>
          <span className='h-10 w-10'>
            <img className='w-full h-full object-contain' src={icon} alt={name} />
          </span>
          <span>
            {name} (<span className='fenton'>{symbol}</span>)
          </span>
        </div>
      </td>
      <td dir='ltr' className='px-4 py-2 fenton text-right text-lg'>
        {unit === 'toman' ? 'T' : '$'} {unit === 'toman' ? price * unitPrice : price}
      </td>
      <td dir='ltr' className={`px-4 py-2 fenton text-right ${changesColor} text-lg`}>
        {changes}
      </td>
      <td className='px-4 py-2 text-black content-center align-middle items-center text-center'>
        <Chart width={200} height={60} series={series} options={chartOptions} />
      </td>
      <td className='px-4 py-2'>
        <button className='bg-white text-black px-4 py-2 rounded-md font-bold'>خرید / فروش</button>
      </td>
    </tr>
  )
}

export default MarketTableRow
