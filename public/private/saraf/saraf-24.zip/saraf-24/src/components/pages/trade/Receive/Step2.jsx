import {useState} from "react";

export default function Receive2({
  state,
  actions,
  resetStep = () => {},
  nextStep = () => {},
  noEnoughCredit,
}) {
  const [showCreditCard, setShowCreditCard] = useState(false);
  
  const okClickHandler = () => {
    // fetch for credit
    const credit = 2000;
    if (credit < state.pay)
      setShowCreditCard(true)
    else nextStep()
  }
  return ( !showCreditCard ?
    <div dir='rtl' className='py-20'>
      <h3 className='text-3xl font-bold text-center mb-8'>بررسی نهایی</h3>
      <div className='bg-white/90 text-gray-700 rounded-3xl p-4'>
        <p className='font-bold mb-2'>
          آیا مطمئن به ادامه خرید{' '}
          <span className='font-sans'>{state.receive}</span>{' '}
          {state.receiveCoin.name} با{' '}
          <span className='font-sans'>{state.pay}</span> {state.payCoin.name} می
          باشید؟
        </p>
        <div className='grid grid-cols-2 gap-2 text-white'>
          <button
            className='bg-neutral-800 py-2 rounded-full text-primary font-bold'
            onClick={okClickHandler}>
            مطمئنم
          </button>
          <button
            onClick={() => resetStep()}
            className='bg-neutral-800 py-2 rounded-full text-custom-brown font-bold'>
            لغو تراکنش
          </button>
        </div>
      </div>
    </div> : noEnoughCredit
  )
}
