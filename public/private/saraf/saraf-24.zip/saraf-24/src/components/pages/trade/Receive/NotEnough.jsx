import SelectBox from '../../../ui/SelectBox'
import { useState } from 'react'

export default function NotEnough({ state }) {
  const [card, setCard] = useState('')

  return (
    <div dir='rtl'>
      <h3 className='text-center font-bold text-2xl mb-1'>انتخاب کارت بانکی</h3>
      <p className='text-sm font-sans text-center mb-6'>
        {state.receive} {state.receiveCoin.value}
      </p>
      <SelectBox
        onChange={value => {
          setCard(value)
        }}
        placeholder='لطفا کارت بانکی خود را انتخاب کنید'
        className='mb-4 bg-white text-black px-4 rounded-full'
        items={[
          {title: 'محسن کریمی - 23432523543263453',
          value: '23432534243543'}
      ]}
      />
      <button className='flex items-center gap-2 mb-8 text-xs'>
        <img src='/images/plussvg.svg' alt='plus' />
        <span>افزودن کارت</span>
      </button>
      <p className='text-center mb-4'>موجودی حساب شما کافی نمیباشد.</p>
      <button className='button block w-full'>افزایش موجودی و خرید</button>
    </div>
  )
}
