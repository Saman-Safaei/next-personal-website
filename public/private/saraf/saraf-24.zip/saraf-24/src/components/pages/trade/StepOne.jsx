import React, { Fragment, useEffect, useRef } from 'react'
import SelectCoin from '../../ui/SelectCoin'

function StepOne({ state, actions, coins = [], nextHandler }) {
  const activeClasses = state.method === 0 ? 'bg-primary' : state.method === 1 ? 'bg-custom-brown' : ''

  const activeTab1 = state.method === 0 ? activeClasses : ''
  const activeTab2 = state.method === 1 ? activeClasses : ''

  const submitTitle = state.method === 0 ? 'خرید' : 'فروش'

  const leftRef = useRef(null)
  const rightRef = useRef(null)

  const setTabHandler = number => {
    if (number === 1) leftRef.current.setCoin('IRT')
    else leftRef.current.reset()

    if (number === 0) rightRef.current.setCoin('IRT')
    else rightRef.current.reset()

    actions.setMethod(number)
  }

  useEffect(() => {
    setTabHandler(0)
  }, [])

  const nextClickHandler = () => {
    if (rightRef.current.coin && leftRef.current.coin && state.pay > 0) nextHandler()
  }

  return (
    <Fragment>
      <div className='grid grid-cols-1 md:grid-cols-2 mb-6'>
        <button
          className={`${activeTab2} p-3 rounded-full w-full font-bold text-lg transition-colors duration-300`}
          onClick={() => setTabHandler(1)}>
          فروش
        </button>
        <button
          className={`${activeTab1} p-3 rounded-full w-full font-bold text-lg transition-colors duration-300`}
          onClick={() => setTabHandler(0)}>
          خرید
        </button>
      </div>
      <div className='grid grid-cols-1 md:grid-cols-[1fr,32px,1fr] gap-4 mb-4'>
        <SelectCoin
          disabled={state.method === 1}
          ref={leftRef}
          items={coins}
          className='order-3 md:order-1'
          onChange={(value, title, zarib) => actions.setReceiveCoin({ name: title, value: value, zarib })}
        />
        <span className='h-8 w-8 self-center justify-self-center -rotate-90 md:rotate-0 order-2'>
          <img src='/images/arrowleft.png' alt='arrowleft' className='object-contain w-full h-full' />
        </span>
        <SelectCoin
          disabled={state.method === 0}
          ref={rightRef}
          items={coins}
          className='order-1 md:order-3'
          onChange={(value, title, zarib) => actions.setPayCoin({ name: title, value: value, zarib })}
        />
      </div>
      <div dir='rtl'>
        <div className='flex flex-col items-stretch gap-4 py-4'>
          <div className='border-solid border-b-2 border-b-white'>
            <h5>پرداخت می کنید</h5>
            <div className='flex flex-row items-stretch'>
              <input
                onChange={ev => actions.onPayChange(ev)}
                type='number'
                value={state.pay.toString()}
                className='block py-2 px-3 grow !bg-transparent'
              />
              <button type='button' className='shrink-0'>
                کل موجودی
              </button>
            </div>
          </div>
          <div className='border-solid border-b-2 border-b-white'>
            <h5>دریافت می کنید</h5>
            <input
              type='number'
              value={state.receive.toString()}
              className='block py-2 px-3 w-full !bg-transparent'
              disabled={true}
            />
          </div>
          <p className='font-sans text-center py-2'>BTC :16,994.15 USDT</p>
          <button
            onClick={nextClickHandler}
            className={`${activeClasses} py-2 px-4 rounded-full block w-full text-center transition-colors duration-300`}>
            {submitTitle}
          </button>
        </div>
      </div>
    </Fragment>
  )
}

export default StepOne
