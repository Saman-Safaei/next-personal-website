import React from 'react'

function MarketTable({ children }) {
  return (
    <div className='w-full overflow-x-auto custom-scroll'>
      <table className='min-w-full'>
        <thead className='border-solid border-y-2 border-gray-400'>
          <tr>
            <th className='py-3 px-4'>ارز دیجیتال</th>
            <th className='py-3 px-4'>قیمت</th>
            <th className='py-3 px-4'>تغییرات 24 ساعت</th>
            <th className='py-3 px-4'>نمودار 24 ساعت</th>
            <th className='py-3 px-4'>عملیات ها</th>
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  )
}

export default MarketTable
