import React from 'react'

function UnitButton({ onSelect, onActivate, name, unit }) {
  return (
    <button
      onClick={() => onSelect(unit)}
      className={`px-2 py-1 border-solid border-b ${onActivate(unit)} transition-colors duration-300`}>
      {name}
    </button>
  )
}

export default UnitButton
