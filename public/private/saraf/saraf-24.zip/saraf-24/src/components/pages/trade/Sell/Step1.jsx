import { Fragment } from 'react'

/**
 *
 * @param state {{pay:number;payCoin:{name: string;value: string;zarib:number;}; receive: number; receiveCoin: {name: string; value: string; zarib: 0;}; method: number;step: number;}}
 * @param resetStep {() => void}
 * @param nextStep {() => void}
 * @return {JSX.Element}
 */
export default function Sell1({ state, resetStep = () => {}, nextStep = () => {} }) {
  const okClickHandler = () => {
    const payValue = state.pay
    const payCoinSymbol = state.payCoin.value
    const receiveCoinSymbol = state.receiveCoin.value

    // ready for send a request //

    nextStep()
  }

  return (
    <div className='py-20'>
      <h2 className='text-center text-3xl font-bold mb-8'>بررسی نهایی</h2>
      <div className='bg-white/90 text-black text-lg p-4 rounded-3xl' dir='rtl'>
        <h3 className='mb-2'>
          آیا مطمئن به ادامه فروش {state.pay} {state.payCoin.name} با {state.receive} {state.receiveCoin.name} می باشید؟
        </h3>
        <div className='grid grid-cols-2 gap-2 text-white'>
          <button className='bg-neutral-800 py-2 rounded-full text-primary font-bold' onClick={okClickHandler}>
            مطمئنم
          </button>
          <button onClick={() => resetStep()} className='bg-neutral-800 py-2 rounded-full text-custom-brown font-bold'>
            لغو تراکنش
          </button>
        </div>
      </div>
    </div>
  )
}
