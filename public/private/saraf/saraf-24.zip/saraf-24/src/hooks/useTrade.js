import { useEffect, useReducer } from 'react'
import { useRouter } from 'next/router'

const initialState = initialMethod => ({
  pay: 0,
  payCoin: { name: '', value: '', zarib: 0 },
  receive: 0,
  receiveCoin: { name: '', value: '', zarib: 0 },
  method:
    typeof initialMethod === 'number' &&
    (initialMethod < 2 || initialMethod >= 0)
      ? initialMethod
      : 0,
  step:
    typeof initialMethod === 'number' &&
    (initialMethod < 2 || initialMethod >= 0)
      ? initialMethod === 0
        ? 3
        : initialMethod === 1
        ? 2
        : 0
      : 0,
  buyState: {
    selectedWallet: 'Saraf24', // this will be "Saraf24" | "Other"
    walletAddress: '',
    channel: '',
  },
  isTransitionSuccessful: false,
})

function tradeReducer(state = initialState(), action) {
  switch (action.type) {
    case 'SET_PAY':
      const setPayValue = +action.payload

      let setPayValueInToman = setPayValue * state.payCoin.zarib
      let setPayReceiveValue = setPayValueInToman / state.receiveCoin.zarib

      return {
        ...state,
        pay: setPayValue,
        receive:
          isNaN(setPayReceiveValue) || setPayReceiveValue === Infinity
            ? 0
            : setPayReceiveValue,
      }
    case 'SET_METHOD':
      return { ...state, method: +action.payload }
    case 'SET_STEP':
      return { ...state, step: action.payload }
    case 'SET_WALLET_CHANNEL':
      return {
        ...state,
        buyState: { ...state.buyState, channel: action.payload },
      }
    case 'SET_PAY_COIN':
      const setPayCoinValue = state.pay

      const setPayCoinValueInToman = setPayCoinValue * action.payload.zarib
      const setPayCoinReceiveValue =
        setPayCoinValueInToman / state.receiveCoin.zarib

      return {
        ...state,
        payCoin: action.payload,
        receive:
          isNaN(setPayCoinReceiveValue) || setPayCoinReceiveValue === Infinity
            ? 0
            : setPayCoinReceiveValue,
      }
    case 'SET_RECEIVE_COIN':
      const setReceiveCoinValue = state.pay

      const setReceiveCoinValueInToman =
        setReceiveCoinValue * state.payCoin.zarib
      const setReceiveCoinReceiveValue =
        setReceiveCoinValueInToman / action.payload.zarib

      return {
        ...state,
        receiveCoin: action.payload,
        receive:
          isNaN(setReceiveCoinReceiveValue) ||
          setReceiveCoinReceiveValue === Infinity
            ? 0
            : setReceiveCoinReceiveValue,
      }
    case 'SET_WALLET_TYPE':
      return {
        ...state,
        buyState: { ...state.buyState, selectedWallet: action.payload },
      }
    case 'SET_WALLET_ADDRESS':
      return {
        ...state,
        buyState: { ...state.buyState, walletAddress: action.payload },
      }
    default:
      return state
  }
}

export default function useTrade(initialMethod) {
  const [state, dispatch] = useReducer(
    tradeReducer,
    initialState(initialMethod),
    undefined
  )

  const router = useRouter()

  useEffect(() => {
    if (
      router &&
      (typeof initialMethod !== 'number' ||
        initialMethod >= 2 ||
        initialMethod < 0)
    )
      router.push({ query: {} })
  }, [router])

  const setPayHandler = (value = 0) => {
    dispatch({ type: 'SET_PAY', payload: value })
  }
  const setReceiveHandler = (value = 0) => {
    dispatch({ type: 'SET_RECEIVE', payload: value })
  }
  const setMethodHandler = (value = 0) => {
    dispatch({ type: 'SET_METHOD', payload: value })
  }
  const onPayChangeHandler = (ev, zarib = 1) => {
    dispatch({ type: 'SET_PAY', payload: ev.target.value })
  }
  const setStepHandler = step => {
    dispatch({ type: 'SET_STEP', payload: step })
  }
  const setPayCoinHandler = payCoin => {
    dispatch({ type: 'SET_PAY_COIN', payload: payCoin })
  }
  const setReceiveCoinHandler = receiveCoin => {
    dispatch({ type: 'SET_RECEIVE_COIN', payload: receiveCoin })
  }
  const setWalletTypeHandler = wallet => {
    dispatch({ type: 'SET_WALLET_TYPE', payload: wallet })
  }
  const onWalletAddressChangeHandler = ev => {
    dispatch({ type: 'SET_WALLET_ADDRESS', payload: ev.target.value })
  }
  const changeChannelHandler = channel => {
    dispatch({ type: 'SET_WALLET_CHANNEL', payload: channel })
  }

  return {
    state,
    actions: {
      setPay: setPayHandler,
      setReceive: setReceiveHandler,
      setMethod: setMethodHandler,
      onPayChange: onPayChangeHandler,
      setStep: setStepHandler,
      setPayCoin: setPayCoinHandler,
      setReceiveCoin: setReceiveCoinHandler,
      setWalletType: setWalletTypeHandler,
      onWalletAddressChange: onWalletAddressChangeHandler,
      setChannel: changeChannelHandler,
    },
  }
}

export const walletTypes = {
  SARAF_WALLET: 'Saraf24',
  OTHER_WALLET: 'Other',
}
