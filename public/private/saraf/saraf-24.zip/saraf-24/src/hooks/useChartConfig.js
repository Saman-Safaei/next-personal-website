import { useId, useMemo } from 'react'

export default function useChartConfig(
  changesData = [0],
  unitPrice = 32,
  unit,
  customTomanName = 'toman'
) {
  const config = {
    chart: {
      toolbar: {
        show: false,
      },
      zoom: {
        enabled: false,
      },
      animations: {
        enabled: false,
      },
      id: useId(),
    },
    xaxis: {
      labels: {
        show: false,
      },
      tooltip: {
        enabled: false,
      },
    },
    yaxis: {
      labels: {
        show: false,
      },
    },
    grid: {
      show: false,
    },
    tooltip: {
      x: {
        show: false,
      },
      marker: {
        show: false,
      },
      y: {
        title: {
          formatter: () => `$`,
        },
      },
    },
  }

  const series = useMemo(
    () => [
      {
        name: 'Prices',
        data: changesData.map(num =>
          unit === customTomanName ? num * unitPrice : num
        ),
      },
    ],
    [unit, unitPrice]
  )

  return { config, series }
}
