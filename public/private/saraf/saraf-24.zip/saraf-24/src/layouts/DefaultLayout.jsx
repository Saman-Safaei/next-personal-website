import Head from 'next/head'
import { Fragment } from 'react'
import Navbar from '../components/navbar/Navbar'
import Header from '../components/header/Header'
import withUIProvider from '../hocs/withUIProvider'
import Drawer from '../components/drawer/Drawer'
import Footer from '../components/footer/Footer'

function DefaultLayout({
  header = false,
  navbar = false,
  title = '',
  navLinks = [],
  children,
  footer,
  theme = 'dark',
}) {
  const siteTitle = title ? `صراف 24 | ${title}` : 'صراف 24'

  return (
    <Fragment>
      <Head>
        <title>{siteTitle}</title>
        <style>{theme === 'dark' ? `
          html {
            background: linear-gradient(to bottom right, #141414, #2e2e2e) center fixed no-repeat;
          }
        ` : `
          html {
            background: linear-gradient(to bottom right, #ffffff, #d8d8d8) center fixed no-repeat;
          }
        `}</style>
      </Head>

      {/* Navbar */}
      {navbar && (
        <header className='px-4 py-6'>
          <Navbar theme={theme} links={navLinks} />
        </header>
      )}

      {/* Header */}
      {header && <Header links={navLinks} />}

      {(header || navbar) && <Drawer links={navLinks} />}

      <main className='text-gray-100 min-h-screen'>{children}</main>

      {footer && <Footer />}
    </Fragment>
  )
}

export default withUIProvider(DefaultLayout)
