/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#2A9D8F",
          dark: "#234A57",
          light: "#32c1b0",
        },
        custom: {
          brown: "#AA6150",
        },
      },
      maxWidth: {
        normal: "72rem",
      },
      screens: {
        special: "860px",
      },
    },
  },
  plugins: [],
}
