module.exports = {
  semi: false,
  singleQuote: true,
  jsxSingleQuote: true,
  bracketSameLine: true,
  arrowParens: 'avoid',
  printWidth: 80
}
